import { Routes } from '@angular/router';
import { ServiceCheckComponent } from './feature/service-check/service-check.component';
import { LoginComponent } from './feature/login/login.component';
import { AddressComponent } from './feature/address/address.component';
import { PackageComponent } from './feature/package/package.component';
import { PanGstComponent } from './feature/pan-gst/pan-gst.component';
import { BookingShellComponent } from './shared/components/booking-shell/booking-shell.component';
import { FreightCalculatorComponent } from './feature/freight-calculator/freight-calculator.component';
import { PaymentSuccessComponent } from './feature/payment-success/payment-success.component';
import { PaymentFailureComponent } from './feature/payment-failure/payment-failure.component';
export const routes: Routes = [
   { path: '', redirectTo: 'login', pathMatch: 'full' },
   {path:'service-check', component: ServiceCheckComponent},
   {path:'login', component: LoginComponent},
   {path:'address', component: AddressComponent},
   {path:'shipment-package', component: PackageComponent},
   {path: 'pan-gst',component: PanGstComponent},
   {path: 'booking-shell', component: BookingShellComponent},
   {path: 'freight-calculator', component: FreightCalculatorComponent},
   { path: 'payment/success', component: PaymentSuccessComponent},
   {path: 'payment/failure',component: PaymentFailureComponent}
];
