import { CanActivateFn } from '@angular/router';

export const bookingStepGuard: CanActivateFn = (route, state) => {
  return true;
};
