import { HttpInterceptorFn } from '@angular/common/http';

export const AuthInterceptor: HttpInterceptorFn = (req, next) => {

  // Only attach token to CRM API requests
  if (req.url.startsWith('https://crm.tciexpress.in/')) {

    const token = localStorage.getItem('token');

    if (token) {

      const authReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });

      return next(authReq);
    }
  }

  return next(req);
};
