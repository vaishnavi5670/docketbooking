export const environment = {
  production: true,
  apiUrl: 'https://onlinebooking.tciexpress.in/api'
};
