
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { Address } from '../models/onlinebooking.model';
import { AddressService, DeliveryAddress } from '../../services/address.service';

type AddressType = 'pickup' | 'delivery';
type AddressTarget = AddressType;

interface AddressSaveResponse {
  success?: boolean;
  message?: string;
  data?: {orderId?: string | number;ORDER_ID?: string | number;};
  orderId?: string | number;
  ORDER_ID?: string | number;
  error?: { message?: string;errors?: {  request?: string[];
    };
  };
}

@Component({
  selector: 'app-address',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, BookingShellComponent],
  templateUrl: './address.component.html',
  styleUrl: './address.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddressComponent implements OnInit {


  pickupAddress: Address = this.createEmptyAddress('pickup');
  deliveryAddress: Address = this.createEmptyAddress('delivery');
  pickupLandmark = '';
  deliveryLandmark = '';
  showSavedAddresses = false;
  selectedAddressTarget: AddressTarget = 'pickup';
  deliveryAddresses: DeliveryAddress[] = [];
  isLoadingSavedAddresses = false;
  isSaving = false;
  apiError = '';
  apiSuccess = '';
  savedAddressApiError = '';
  today = '';
  deliveryMinDate = '';

  private readonly STORAGE = {
    userId: 'bookingUserId',
    activeBookingUser: 'activeBookingUserId',
    mobileKeys: ['mobileNo', 'bookingMobileNo', 'mobile'],
    pickupAddress: 'tci_booking_pickup_address',
    deliveryAddress: 'tci_booking_delivery_address',
    pickupPincode: 'serviceCheckPickupPincode',
    deliveryPincode: 'serviceCheckDeliveryPincode',
    bookingSession: 'tci_active_booking_session',
    bookingSessionUser: 'tci_active_booking_session_user',
    pickupPincodeLegacy: 'pickupPincode',
    deliveryPincodeLegacy: 'deliveryPincode',
    pickupCity: 'pickupCity',
    pickupState: 'pickupState',
    deliveryCity: 'deliveryCity',
    deliveryState: 'deliveryState',
    bookingOrderId: 'bookingOrderId',
    orderId: 'orderId'
  } as const;


  private readonly MOBILE_REGEX = /^[6-9]\d{9}$/;
  private readonly PINCODE_REGEX = /^\d{6}$/;
  private readonly NAME_REGEX = /^[A-Za-z]+(?:[A-Za-z .'-]*[A-Za-z])?$/;
  private readonly EMAIL_REGEX = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  private readonly LANDMARK_ALLOWED_REGEX = /[^A-Za-z0-9\s.,/#()\-]/g;
  private readonly TEXT_ALLOWED_REGEX = /[^A-Za-z .'-]/g;

  constructor(private readonly addressService: AddressService, private readonly router: Router, private readonly cdr: ChangeDetectorRef) { }


  ngOnInit(): void {
    this.setMinimumDates();
    const userId = this.getLoggedInUserId();
    const hasActiveSession = !!userId && this.isCurrentBookingSession();
    if (hasActiveSession) {
      this.loadAddresses();
    } else {
      this.startFreshAddressForm();
      this.loadPreviousBookingPincodes();
    }
    this.loadServiceCheckData();
    this.markForCheck();
  }


  private createEmptyAddress(type: AddressType): Address {
    return {
      contactName: '',
      mobile: '',
      pickupEmail: '',
      deliveryEmail: '',
      companyName: '',
      address: '',
      pincode: '',
      city: '',
      state: '',
      pickupLandmark: '',
      deliveryLandmark: '',
      saveAddress: false,
      type
    };
  }


  private getLoggedInUserId(): number | null {
    const value = localStorage.getItem(this.STORAGE.userId);
    if (!value) {
      return null;
    }
    const userId = Number(value);
    return Number.isInteger(userId) && userId > 0
      ? userId : null;
  }

  private getLoggedInMobile(): string {
    for (const key of this.STORAGE.mobileKeys) {
      const value = localStorage.getItem(key)?.trim() ?? '';
      if (this.MOBILE_REGEX.test(value)) {
        return value;
      }
    }
    return '';
  }

  private getBookingSessionId(): string {
    return (
      localStorage.getItem(this.STORAGE.bookingSession)?.trim() ?? ''
    );
  }

  private isCurrentBookingSession(): boolean {
    const userId = this.getLoggedInUserId();
    const sessionId = this.getBookingSessionId();
    const sessionUserId = localStorage.getItem(this.STORAGE.bookingSessionUser)?.trim();
    return !!(
      userId &&
      sessionId &&
      sessionUserId &&
      sessionUserId === String(userId)
    );
  }

  private createBookingSession(userId: number): void {
    const sessionId = `${userId}_${Date.now()}`;
    localStorage.setItem(this.STORAGE.bookingSession, sessionId);
    localStorage.setItem(this.STORAGE.bookingSessionUser, String(userId));
    localStorage.removeItem(this.STORAGE.bookingOrderId);
    localStorage.removeItem(this.STORAGE.orderId);
    localStorage.removeItem(this.STORAGE.activeBookingUser);
  }


  private startNewBookingSession(userId: number): void {
    const pickupPincode = this.pickupAddress.pincode?.trim() ?? '';
    const deliveryPincode = this.deliveryAddress.pincode?.trim() ?? '';
    this.createBookingSession(userId);
    if (pickupPincode) {
      localStorage.setItem(this.STORAGE.pickupPincode, pickupPincode);
    }
    if (deliveryPincode) {
      localStorage.setItem(this.STORAGE.deliveryPincode, deliveryPincode
      );
    }
  }

  private getBookingStorageKey(baseKey: string): string {
    const userId = this.getLoggedInUserId();
    const sessionId = this.getBookingSessionId();
    if (!userId || !sessionId) { return ''; }
    return `${baseKey}_${userId}_${sessionId}`;
  }

  private startFreshAddressForm(): void {
    this.pickupAddress = this.createEmptyAddress('pickup');
    this.deliveryAddress = this.createEmptyAddress('delivery');
    this.pickupLandmark = '';
    this.deliveryLandmark = '';
    this.deliveryAddresses = [];
    this.clearMessages();
  }

  private loadPreviousBookingPincodes(): void {
    const userId = this.getLoggedInUserId();
    if (!userId) { return; }
    const pickupPincode = localStorage.getItem(this.STORAGE.pickupPincodeLegacy) || localStorage.getItem(this.STORAGE.pickupPincode) || '';
    const deliveryPincode = localStorage.getItem(this.STORAGE.deliveryPincodeLegacy) || localStorage.getItem(this.STORAGE.deliveryPincode) || '';
    this.pickupAddress = { ...this.pickupAddress, mobile: this.getLoggedInMobile(), pincode: pickupPincode };
    this.deliveryAddress = { ...this.deliveryAddress, pincode: deliveryPincode };
  }


  private setMinimumDates(): void {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    this.today = `${year}-${month}-${day}`;
    this.deliveryMinDate = this.today;
  }


  private saveAddressesLocally(): void {
    if (!this.isCurrentBookingSession()) { return; }
    const pickupKey = this.getBookingStorageKey(this.STORAGE.pickupAddress);
    const deliveryKey = this.getBookingStorageKey(this.STORAGE.deliveryAddress);
    if (!pickupKey || !deliveryKey) { return; }
    const pickup: Address = { ...this.pickupAddress, pickupLandmark: this.pickupLandmark || this.pickupAddress.pickupLandmark || '', type: 'pickup' };
    const delivery: Address = {
      ...this.deliveryAddress, deliveryLandmark:
        this.deliveryLandmark ||
        this.deliveryAddress.deliveryLandmark || '',
      type: 'delivery'
    };
    this.setLocalStorage(pickupKey, pickup);
    this.setLocalStorage(deliveryKey, delivery);
  }

  private loadAddresses(): void {
    const pickupKey = this.getBookingStorageKey(this.STORAGE.pickupAddress);
    const deliveryKey = this.getBookingStorageKey(this.STORAGE.deliveryAddress);
    if (!pickupKey || !deliveryKey) { this.startFreshAddressForm(); return; }
    try {
      const pickupData = this.getLocalStorage<Address>(pickupKey);
      if (pickupData) {
        this.pickupAddress = {
          ...this.createEmptyAddress('pickup'), ...pickupData,
          type: 'pickup'
        };
        this.pickupLandmark = pickupData.pickupLandmark || '';
      }
      const deliveryData =
        this.getLocalStorage<Address>(deliveryKey);
      if (deliveryData) {
        this.deliveryAddress = { ...this.createEmptyAddress('delivery'), ...deliveryData, type: 'delivery' };
        this.deliveryLandmark = deliveryData.deliveryLandmark || '';
      }
    } catch (error) {
      console.error(
        'Unable to restore booking address:',
        error
      );
      this.startFreshAddressForm();
    }
  }

  private setLocalStorage<T>(key: string, value: T): void {
    try {
      localStorage.setItem(
        key,
        JSON.stringify(value)
      );
    } catch (error) {
      console.error(
        `Unable to save localStorage key "${key}":`,
        error
      );
    }
  }

  private getLocalStorage<T>(key: string): T | null {
    try {
      const value = localStorage.getItem(key);
      if (!value) {
        return null;
      }
      return JSON.parse(value) as T;
    } catch (error) {
      console.error(
        `Unable to read localStorage key "${key}":`,
        error
      );
      return null;
    }
  }

private loadServiceCheckData(): void {

  const loggedInMobile = this.getLoggedInMobile();
  const pickupPincode =localStorage.getItem(  'serviceCheckPickupPincode')?.trim()||localStorage.getItem(  this.STORAGE.pickupPincodeLegacy)?.trim()||'';
  const deliveryPincode =localStorage.getItem(  'serviceCheckDeliveryPincode')?.trim()||localStorage.getItem(  this.STORAGE.deliveryPincodeLegacy)?.trim()||'';
  const pickupCity =localStorage.getItem('serviceCheckPickupCity')?.trim()||localStorage.getItem(  this.STORAGE.pickupCity)?.trim()||'';
  const pickupState =localStorage.getItem(  'serviceCheckPickupState')?.trim()||localStorage.getItem(this.STORAGE.pickupState)?.trim()||'';
  const deliveryCity =localStorage.getItem(  'serviceCheckDeliveryCity')?.trim()||localStorage.getItem(  this.STORAGE.deliveryCity)?.trim()||'';
  const deliveryState = localStorage.getItem(  'serviceCheckDeliveryState' )?.trim() || localStorage.getItem(   this.STORAGE.deliveryState )?.trim() ||'';

  if (pickupPincode) {
    this.pickupAddress = {...this.pickupAddress,
      mobile:this.pickupAddress.mobile?.trim()|| loggedInMobile,
      pincode: pickupPincode,
      city: pickupCity || this.pickupAddress.city?.trim() || '',
      state: pickupState || this.pickupAddress.state?.trim() || '',
      type: 'pickup'
    };
  }

  if (deliveryPincode) {
    this.deliveryAddress = {...this.deliveryAddress,
      pincode: deliveryPincode,
      city:deliveryCity ||this.deliveryAddress.city?.trim() || '',
      state:deliveryState ||this.deliveryAddress.state?.trim() ||'',
      type: 'delivery'
    };
  }
  this.pickupLandmark =this.pickupAddress.pickupLandmark ||this.pickupLandmark ||'';
  this.deliveryLandmark =this.deliveryAddress.deliveryLandmark ||this.deliveryLandmark ||'';
  this.saveAddressesLocally();
  this.markForCheck();
}

private getFirstStorageValue(keys: readonly string[]): string {
    for (const key of keys) {
      const value = localStorage.getItem(key)?.trim();
      if (value) {
        return value;
      }
    }
    return '';
  }


  onAddressFieldChange(): void {
    this.saveAddressesLocally();
  }

  onMobileInput(event: Event, addressType: AddressType): void {
    const input = event.target as HTMLInputElement;
    const value = input.value.replace(/\D/g, '').slice(0, 10);
    input.value = value;
    if (addressType === 'pickup') {
      this.pickupAddress = { ...this.pickupAddress, mobile: value };
    }
    else {
      this.deliveryAddress = { ...this.deliveryAddress, mobile: value };
    }
    this.saveAddressesLocally();
    this.markForCheck();
  }

  onPincodeInput(event: Event, addressType: AddressType): void {
    const input = event.target as HTMLInputElement;
    const value = input.value.replace(/\D/g, '').slice(0, 6);
    input.value = value;
    if (addressType === 'pickup') {
      this.pickupAddress = { ...this.pickupAddress, pincode: value };
    } else {
      this.deliveryAddress = {
        ...this.deliveryAddress,
        pincode: value
      };
    }
    this.saveAddressesLocally();
    this.markForCheck();
  }

  onTextInput(
    event: Event,
    field:| 'pickupContactName'| 'deliveryContactName'| 'pickupCity'| 'deliveryCity'| 'pickupState'| 'deliveryState'| 'pickupCompanyName'| 'deliveryCompanyName'| 'pickupLandmark' | 'deliveryLandmark'): void {
    const input = event.target as HTMLInputElement;
    let value = input.value;
    if (field === 'pickupLandmark' ||field === 'deliveryLandmark') {
      value = value
        .replace(this.LANDMARK_ALLOWED_REGEX, '')
        .slice(0, 100);
    } else {
      value = value.replace(
        this.TEXT_ALLOWED_REGEX,
        ''
      );
    }
    input.value = value;
    switch (field) {
      case 'pickupContactName':
        this.pickupAddress.contactName = value;
        break;

      case 'deliveryContactName':
        this.deliveryAddress.contactName = value;
        break;

      case 'pickupCity':
        this.pickupAddress.city = value;
        break;

      case 'deliveryCity':
        this.deliveryAddress.city = value;
        break;

      case 'pickupState':
        this.pickupAddress.state = value;
        break;

      case 'deliveryState':
        this.deliveryAddress.state = value;
        break;

      case 'pickupCompanyName':
        this.pickupAddress.companyName = value;
        break;

      case 'deliveryCompanyName':
        this.deliveryAddress.companyName = value;
        break;

      case 'pickupLandmark':
        this.pickupLandmark = value;
        this.pickupAddress.pickupLandmark = value;
        break;

      case 'deliveryLandmark':
        this.deliveryLandmark = value;
        this.deliveryAddress.deliveryLandmark = value;
        break;
    }
    this.saveAddressesLocally();
    this.markForCheck();
  }


  swapAddresses(): void {
    const pickup = { ...this.pickupAddress };
    const delivery = { ...this.deliveryAddress };
    const pickupLandmark = this.pickupLandmark;
    const deliveryLandmark = this.deliveryLandmark;
    const pickupMobile = this.pickupAddress.mobile;
    this.pickupAddress = { ...delivery, type: 'pickup', mobile: pickupMobile };
    this.deliveryAddress = { ...pickup, type: 'delivery' };
    this.pickupLandmark = deliveryLandmark;
    this.deliveryLandmark = pickupLandmark;
    this.pickupAddress.pickupLandmark = this.pickupLandmark;
    this.deliveryAddress.deliveryLandmark = this.deliveryLandmark;
    this.clearMessages();
    this.saveAddressesLocally();
    this.markForCheck();
  }

  openSavedAddresses(): void {
    this.savedAddressApiError = '';
    this.showSavedAddresses = true;
    const userId = this.getLoggedInUserId();
    if (!userId) {
      this.savedAddressApiError = 'User session not found. Please login again.';
      this.deliveryAddresses = [];
      this.markForCheck();
      return;
    }
    this.isLoadingSavedAddresses = true;
    this.markForCheck();
    this.addressService.getDeliveryAddresses(userId).subscribe({
      next: response => {
        this.isLoadingSavedAddresses = false;
        if (response?.success) {
          this.deliveryAddresses =
            response.data ?? [];
        } else {
          this.deliveryAddresses = [];
          this.savedAddressApiError =
            response?.message ||
            'Unable to fetch saved addresses.';
        }
        this.markForCheck();
      },
      error: error => {
        this.isLoadingSavedAddresses = false;
        this.deliveryAddresses = [];
        this.savedAddressApiError =
          this.getApiErrorMessage(
            error,
            'Unable to fetch saved addresses. Please try again.'
          );
        this.markForCheck();
      }
    });
  }

  closeSavedAddresses(): void {
    this.showSavedAddresses = false;
    this.savedAddressApiError = '';
    this.markForCheck();
  }

  selectSavedAddress(address: DeliveryAddress): void {
    const savedEmail = (address.email ?? '').trim();
    const loggedInMobile = this.getLoggedInMobile();
    if (this.selectedAddressTarget === 'pickup') {
      this.pickupAddress = {
        ...this.pickupAddress,
        contactName: address.contactName ?? '',
        mobile: loggedInMobile,
        pickupEmail: savedEmail,
        companyName: address.companyName ?? '',
        address: address.address ?? '',
        pincode: address.pincode ?? '',
        city: address.city ?? '',
        state: address.state ?? '',
        pickupLandmark: address.landmark ?? '',
        saveAddress: false,
        type: 'pickup'
      };
      this.pickupLandmark = address.landmark ?? '';
    } else {
      this.deliveryAddress = {
        ...this.deliveryAddress,
        contactName: address.contactName ?? '',
        mobile: address.mobileNumber ?? '',
        deliveryEmail: savedEmail,
        companyName: address.companyName ?? '',
        address: address.address ?? '',
        pincode: address.pincode ?? '',
        city: address.city ?? '',
        state: address.state ?? '',
        deliveryLandmark: address.landmark ?? '',
        saveAddress: false,
        type: 'delivery'
      };
      this.deliveryLandmark = address.landmark ?? '';
    }
    this.showSavedAddresses = false;
    this.savedAddressApiError = '';
    this.saveAddressesLocally();
    this.cdr.detectChanges();
  }


  private addToSavedAddresses(address: Address): void {
    const existingKey =this.getBookingStorageKey('tci_booking_saved_addresses');
    if (!existingKey) {
      return;
    }
    const existing =this.getLocalStorage<Address[]>( existingKey) ?? [];
    const newAddress: Address = {...address,saveAddress: true};
    const index = existing.findIndex(
      item =>
        item.mobile === newAddress.mobile &&
        item.pincode === newAddress.pincode &&
        item.address
          .trim()
          .toLowerCase() ===
        newAddress.address
          .trim()
          .toLowerCase()
    );
    if (index >= 0) {
      existing[index] = newAddress;
    } else {
      existing.unshift(newAddress);
    }
    this.setLocalStorage(
      existingKey,
      existing
    );
  }

  private validateDirectAddress(address: Address, type: 'Pickup' | 'Delivery'): boolean {
    const label = type.toLowerCase();
    const contactName = address.contactName?.trim() ?? '';
    if (!contactName) {
      this.apiError = `Please enter ${label} contact name.`;
      return false;
    }
    if (!this.NAME_REGEX.test(contactName)) {
      this.apiError = `${type} contact name should contain alphabets only.`;
      return false;
    }
    const mobile = address.mobile?.trim() ?? '';
    if (!mobile) {
      this.apiError =
        `Please enter ${label} mobile number.`;
      return false;
    }
    if (!this.MOBILE_REGEX.test(mobile)) {
      this.apiError = `Please enter a valid 10 digit ${label} mobile number.`;
      return false;
    }
    if (type === 'Pickup') {
      const email = address.pickupEmail?.trim() ?? '';

      if (!email) {
        this.apiError = 'Please enter Pickup email.';
        return false;
      }

      if (!this.EMAIL_REGEX.test(email)) {
        this.apiError = 'Please enter a valid Pickup email address.';
        return false;
      }
    }

    const companyName = address.companyName?.trim() ?? '';
    if (
      companyName && !/[A-Za-z]/.test(companyName)
    ) {
      this.apiError = `${type} company name must contain at least one alphabet.`;
      return false;
    }
    const addressText = address.address?.trim() ?? '';
    if (!addressText) {
      this.apiError = `Please enter ${label} address.`;
      return false;
    }
    if (!/[A-Za-z]/.test(addressText)) {
      this.apiError = `${type} address must contain valid text.`;
      return false;
    }
    const pincode = address.pincode?.trim() ?? '';
    if (!pincode) {
      this.apiError = `Please enter ${label} pincode.`;
      return false;
    }
    if (!this.PINCODE_REGEX.test(pincode)) {
      this.apiError = `Please enter a valid 6 digit ${label} pincode.`;
      return false;
    }
    const state = address.state?.trim() ?? '';
    if (!state) {
      this.apiError = `Please select ${label} state.`;
      return false;
    }
    if (!this.NAME_REGEX.test(state)) {
      this.apiError = `${type} state should contain alphabets only.`;
      return false;
    }
    return true;
  }


  private validateAddresses(): boolean {
    if (
      !this.validateDirectAddress(
        this.pickupAddress,
        'Pickup'
      )
    ) {
      return false;
    }
    return this.validateDirectAddress(
      this.deliveryAddress,
      'Delivery'
    );
  }


  private buildAddressPayload(): Record<string, unknown> {
    const userId = this.getLoggedInUserId();
    if (!userId) {
      throw new Error(
        'User session not found. Please login again.'
      );
    }
    return {
      userId,
      pickupContactName: this.pickupAddress.contactName?.trim() || '',
      pickupMobileNumber: this.pickupAddress.mobile?.trim() || '',
      pickupEmail: this.pickupAddress.pickupEmail?.trim() || '',
      pickupCompanyName: this.pickupAddress.companyName?.trim() || '',
      pickupAddress: this.pickupAddress.address?.trim() || '',
      pickupPincode: this.pickupAddress.pincode?.trim() || '',
      pickupCity: this.pickupAddress.city?.trim() || '',
      pickupState: this.pickupAddress.state?.trim() || '',
      pickupLandmark: this.pickupAddress.pickupLandmark?.trim() || this.pickupLandmark?.trim() || '',
      deliveryContactName: this.deliveryAddress.contactName?.trim() || '',
      deliveryMobileNumber: this.deliveryAddress.mobile?.trim() || '',
      deliveryEmail: this.deliveryAddress.deliveryEmail?.trim() || '',
      deliveryCompanyName: this.deliveryAddress.companyName?.trim() || '',
      deliveryAddress: this.deliveryAddress.address?.trim() || '',
      deliveryPincode: this.deliveryAddress.pincode?.trim() || '',
      deliveryCity: this.deliveryAddress.city?.trim() || '',
      deliveryState: this.deliveryAddress.state?.trim() || '',
      deliveryLandmark: this.deliveryAddress.deliveryLandmark?.trim() || this.deliveryLandmark?.trim() || ''
    };
  }

  continueBooking(): void {
    if (this.isSaving) { return; } this.clearMessages();
    const userId = this.getLoggedInUserId();
    if (!userId) {
      this.apiError = 'User session not found. Please login again.';
      this.markForCheck();
      return;
    }
    if (!this.validateAddresses()) { this.markForCheck(); return; }
    if (!this.isCurrentBookingSession()) { this.startNewBookingSession(userId); }
    this.saveAddressesLocally();
    if (this.pickupAddress.saveAddress) {
      this.addToSavedAddresses(
        this.pickupAddress
      );
    }
    if (this.deliveryAddress.saveAddress) {
      this.addToSavedAddresses(
        this.deliveryAddress
      );
    }
    let payload: Record<string, unknown>;
    try {
      payload = this.buildAddressPayload();
    } catch (error: unknown) {
      console.error('Unable to build address payload:', error);
      this.apiError = error instanceof Error ? error.message : 'Unable to create address request.';
      this.markForCheck();
      return;
    }
    this.isSaving = true;
    this.markForCheck();
    this.addressService
      .saveAddress(payload)
      .subscribe({
        next: response => {
          this.handleAddressSaveSuccess(
            response,
            userId
          );
        },
        error: error => {
          this.handleAddressSaveError(error);
        }
      });
  }

  private handleAddressSaveSuccess(response: AddressSaveResponse, userId: number): void {
    this.isSaving = false;
    if (!this.isApiSuccess(response)) {
      this.apiError = response?.message || response?.error?.message || 'Unable to save address.';
      this.markForCheck();
      return;
    }
    const orderId = response?.data?.orderId ?? response?.data?.ORDER_ID ?? response?.orderId ?? response?.ORDER_ID;
    if (!orderId) {
      this.apiError = 'Address saved successfully, but Order ID was not generated. Please try again.';
      this.markForCheck();
      return;
    }
    const orderIdString = String(orderId);
    localStorage.setItem(this.STORAGE.bookingOrderId, orderIdString);
    localStorage.setItem(this.STORAGE.orderId, orderIdString);
    localStorage.setItem(this.STORAGE.activeBookingUser, String(userId));
    this.saveAddressesLocally();
    this.navigateAfterAddressSave(userId);
  }


  private handleAddressSaveError(error: unknown): void {
    console.error('ADDRESS API ERROR:', error);
    this.isSaving = false;
    this.saveAddressesLocally();
    this.apiError =
      this.getApiErrorMessage(
        error,
        'Unable to save address. Please try again.'
      );
    this.markForCheck();
  }


  private navigateAfterAddressSave(userId: number): void {
    const mobile = this.getLoggedInMobile();
    let panGstCompleted = false;
    if (mobile) {
      panGstCompleted =
        localStorage.getItem( `panGstCompleted_mobile_${mobile}`) === 'true';
    }
    if (!panGstCompleted) {
      panGstCompleted =
        localStorage.getItem(`panGstCompleted_${userId}`) === 'true';
    }
    if (panGstCompleted) {
      void this.router.navigate([
        '/shipment-package'
      ]);
      return;
    }
    void this.router.navigate([
      '/pan-gst'
    ]);
  }



  private isApiSuccess(
    response: AddressSaveResponse | null | undefined): boolean {
    if (!response) { return false; }
    if (response.success === false) { return false; }
    if (response.success === true) {
      return true;
    }
    return !!(
      response.orderId ||
      response.ORDER_ID ||
      response.data?.orderId ||
      response.data?.ORDER_ID
    );
  }

  private getApiErrorMessage(error: unknown, fallback: string): string {
    if (!error || typeof error !== 'object') {
      return fallback;
    }
    const apiError = error as {
      error?: {
        message?: string;
        errors?: {
          request?: string[];
        };
      };
      message?: string;
    };
    return (
      apiError.error?.message ||
      apiError.error?.errors?.request?.[0] ||
      apiError.message ||
      fallback
    );
  }


  deleteSavedAddress(address: DeliveryAddress, event: Event): void {
    event.stopPropagation();
    const confirmed = window.confirm(
      'Are you sure you want to delete this saved address?'
    );
    if (!confirmed) {
      return;
    }
    this.deliveryAddresses =
      this.deliveryAddresses.filter(
        item =>
          !this.isSameSavedAddress(
            item,
            address
          )
      );
    const key =
      this.getBookingStorageKey(
        'tci_booking_saved_addresses'
      );
    if (key) {
      const cached =
        this.getLocalStorage<Address[]>(
          key
        ) ?? [];
      const updated =
        cached.filter(
          item =>
            !this.isSameSavedAddress(
              item,
              address
            )
        );

      this.setLocalStorage(
        key,
        updated
      );
    }
    this.markForCheck();
  }

  private isSameSavedAddress(
    address1: DeliveryAddress | Address,
    address2: DeliveryAddress | Address): boolean {
    const mobile1 =
      'mobileNumber' in address1
        ? address1.mobileNumber || ''
        : address1.mobile || '';
    const mobile2 =
      'mobileNumber' in address2
        ? address2.mobileNumber || ''
        : address2.mobile || '';
    const pincode1 =
      address1.pincode || '';
    const pincode2 =
      address2.pincode || '';
    const address1Text =
      (address1.address || '')
        .trim()
        .toLowerCase();
    const address2Text =
      (address2.address || '')
        .trim()
        .toLowerCase();
    return (
      mobile1 === mobile2 &&
      pincode1 === pincode2 &&
      address1Text === address2Text
    );
  }


  private clearMessages(): void { this.apiError = ''; this.apiSuccess = ''; this.savedAddressApiError = ''; }

  private markForCheck(): void {
    this.cdr.markForCheck();
  }
}

