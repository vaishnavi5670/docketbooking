import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillDocketPreviewComponent } from './bill-docket-preview.component';

describe('BillDocketPreviewComponent', () => {
  let component: BillDocketPreviewComponent;
  let fixture: ComponentFixture<BillDocketPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BillDocketPreviewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BillDocketPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
