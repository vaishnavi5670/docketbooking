import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';

@Component({
  selector: 'app-bill-docket-preview',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterModule,BookingShellComponent],
  templateUrl: './bill-docket-preview.component.html',
  styleUrl: './bill-docket-preview.component.css'
})
export class BillDocketPreviewComponent {
   activePreview = 'invoice';

  invoiceNo = 'T1VS-26/001234';

  invoiceDate = '21 MAY 2025';

  docketNo = 'T1 MK 2025 00251';

  customerName = 'ABC Pvt. Ltd.';

  customerAddress = 'Plot No. 123, Sector 45,';

  customerCity = 'Gurgaon, Haryana - 122003';

  customerGstin = '06ABCDE1234Z5';

  pickupLocation = 'Gurgaon';

  deliveryLocation = 'Delhi';

  packageCount = 1;

  actualWeight = 12.50;

  freightCharges = 902.00;

  cgst = 81.18;

  sgst = 81.18;

  totalInvoiceValue = 964.36;


  viewFullPreview(): void {
    console.log('Opening full bill and docket preview');
  }
}
