import { Component } from '@angular/core';
import {RouterLink} from '@angular/router'
import {BookingShellComponent} from '../../shared/components/booking-shell/booking-shell.component';
@Component({
  selector: 'app-booking-confirmation',
  standalone: true,
  imports: [BookingShellComponent],
  templateUrl: './booking-confirmation.component.html',
  styleUrl: './booking-confirmation.component.css'
})
export class BookingConfirmationComponent {

}
