import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocketNumberGenerationComponent } from './docket-number-generation.component';

describe('DocketNumberGenerationComponent', () => {
  let component: DocketNumberGenerationComponent;
  let fixture: ComponentFixture<DocketNumberGenerationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DocketNumberGenerationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DocketNumberGenerationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
