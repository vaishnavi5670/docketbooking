import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';

@Component({
  selector: 'app-docket-number-generation',
  standalone: true,
  imports: [RouterLink,BookingShellComponent],
  templateUrl: './docket-number-generation.component.html',
  styleUrl: './docket-number-generation.component.css'
})
export class DocketNumberGenerationComponent {

}
