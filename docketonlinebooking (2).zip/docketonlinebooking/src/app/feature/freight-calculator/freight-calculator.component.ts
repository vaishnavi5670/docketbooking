import { CommonModule, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { FreightCalculatorService } from '../../services/freight-service';
import { PaymentService} from '../../services/payment.service';
import { PayUData } from '../models/onlinebooking.model';
import { ShipmentService } from '../../services/shipment.service';
import {CouponService,Coupon} from '../../services/coupon.service';


@Component({
  selector: 'app-freight-calculator',
  standalone: true,
  imports: [CommonModule,FormsModule,BookingShellComponent,RouterLink],
  templateUrl: './freight-calculator.component.html',
  styleUrl: './freight-calculator.component.css'
})


export class FreightCalculatorComponent
  implements OnInit {
  isCalculating = false;
  isPaying = false;
  isLoadingShipment = false;
  couponLoading = false;

  errorMessage = '';
  successMessage = '';
  couponError = '';
  freightCalculated = false;
  serviceType = '';
  serviceTypeCode = '';
  shipmentType = '';
  materialItem = '';
  fromLocation = '';
  toLocation = '';
  fromPincode = '';
  toPincode = '';
  noOfPackages = 1;
  actualWeight = 0;
  volumetricWeight = 0;
  chargeableWeight = 0;
  declaredValue = 0;
  packageContentType = '';
  packageDescription = '';
  pickupDate = '';
  preferredTime = '';
  remarks = '';
  orderId = '';
  surfaceLength = 0;
  surfaceWidth = 0;
  surfaceHeight = 0;
  surfaceCFT = 0;
  airLength = 0;
  airWidth = 0;
  airHeight = 0;
  airCFT = 0;
  pickupContactName = '';
  pickupMobileNumber = '';
  pickupCompanyName = '';
  pickupAddress = '';
  pickupCity = '';
  pickupState = '';
  pickupAddressDate = '';
  pickupTime = '';
  deliveryContactName = '';
  deliveryMobileNumber = '';
  deliveryCompanyName = '';
  deliveryAddress = '';
  deliveryCity = '';
  deliveryState = '';
  deliveryAddressDate = '';
  deliveryTime = '';
  panNo = '';
  custMobile = '';
  customerName = '';
  customerEmail = '';
  customerPhone = '';
  tbbFlag = 'N';
  basis = '1';
  codAmount: number | string = 0;
  mbg = 'N';
  readonly frt = '100';
  baseFreight = 0;
  fuelSurcharge = 0;
  deliveryProtection = 0;
  handlingCharge = 0;
  fodCharge = 0;
  codCharge = 0;
  odaCharge = 0;
  miscCharge = 0;
  odaDiscount = 0;
  ngtCharge = 0;
  sdcCharge = 0;
  daccCharge = 0;
  subtotal = 0;
  gst = 0;
  totalFreight = 0;
  fuelSurchargePercent = 0;
  gstPercent = 0;
  coupons: Coupon[] = [];
  selectedCoupon = '';
  couponDiscount = 0;
  couponApplied = false;
  payableAmount = 0;

  constructor(
    private readonly freightCalculatorService: FreightCalculatorService,
    private readonly router:Router,
    private readonly location:Location,
    private readonly paymentService:PaymentService,
    private readonly shipmentService:ShipmentService,
    private readonly couponService:CouponService
  ) {}

  ngOnInit(): void {
    this.loadBookingDetails();
    this.loadCoupons();
    this.loadShipmentDetails();
  }


  loadCoupons(): void {
    this.couponLoading = true;
    this.couponError = '';
    const userId = Number(localStorage.getItem('userId')) || 2;
    this.couponService.getCoupons(userId).subscribe({next: (response) => { this.couponLoading = false;
        if (response?.status &&Array.isArray(response?.data))
        {this.coupons = response.data;
          if (this.coupons.length === 0) {
          this.couponError = 'No coupons available.';
          }
        } else {
          this.coupons = [];
          this.couponError = 'No coupons available.';
        }
      },
      error: (error: any) => {
        this.couponLoading = false;
        this.coupons = [];
        this.couponError =
          error?.error?.message ||
          'Unable to load coupons. Please try again.';
      }
    });
}

  private loadBookingDetails(): void {
    this.panNo =this.getLocalStorageValue(['panNo','pan_No','panNumber','pan']);
    this.custMobile =this.getLocalStorageValue([  'custMobile',  'mobileNumber',  'mobile', 'mobileNo']);
    this.customerPhone =this.custMobile;
    this.customerName =this.getLocalStorageValue(['customerName','firstName','custName','contactName','name']);
    this.customerEmail =this.getLocalStorageValue(['customerEmail','email','custEmail','emailAddress']);
    this.orderId =this.getLocalStorageValue(['bookingOrderId','orderId','ORDER_ID','orderID']);
  }



  private loadShipmentDetails(): void {
    if (!this.orderId) {
      this.errorMessage ='Booking Order ID not found. Please complete the booking details first.';
      return;
    }
    this.isLoadingShipment = true;
    this.errorMessage = '';
    this.shipmentService.getShipmentPackageDetails(this.orderId)
      .subscribe({next: (response: any) => {this.isLoadingShipment = false;
          if ( !response?.success ||!response?.data
          ) {this.errorMessage =response?.message || 'Unable to fetch shipment details.';
            return;
          }
          this.populateShipmentDetails(
            response.data
          );
        },
        error: (error: any) => {
          this.isLoadingShipment = false;
          this.errorMessage =
            error?.error?.message ||
            error?.message ||
            'Unable to fetch shipment details. Please try again.';
        }
      });
  }

  private populateShipmentDetails(data: any): void {

  console.log('========== SHIPMENT DETAILS ==========');
  console.log('Complete shipment response:', data);
  console.log('data.serviceType:', data?.serviceType);
  console.log('typeof data.serviceType:', typeof data?.serviceType);
  console.log('======================================');

  this.orderId = data.orderId || this.orderId;

  // IMPORTANT: service code is the source of truth
  this.serviceTypeCode = String(data?.serviceType ?? '').trim();

this.serviceType = this.getServiceTypeName(
  this.serviceTypeCode
);
  console.log('========== SERVICE TYPE ==========');
  console.log('serviceTypeCode:', this.serviceTypeCode);
  console.log('serviceType:', this.serviceType);
  console.log('serviceTypeDisplay:', this.serviceTypeDisplay);
  console.log('=================================');

  this.shipmentType = data.shipmentType || '';
  this.materialItem = data.materialItem || '';

  this.fromLocation = this.buildLocation(
    data.pickup?.city,
    data.pickup?.pincode
  );

  this.fromPincode = data.pickup?.pincode || '';

  this.toLocation = this.buildLocation(
    data.delivery?.city,
    data.delivery?.pincode
  );

  this.toPincode = data.delivery?.pincode || '';

  this.noOfPackages = 1;

  this.actualWeight =
    this.toNumber(data.actualWeight);

  this.volumetricWeight =
    this.toNumber(data.volumetricCFT);

  this.chargeableWeight =
    this.toNumber(data.chargeableWeight);

  this.declaredValue =
    this.toNumber(data.declaredValue);

  this.packageContentType =
    data.packageContentType || '';

  this.packageDescription =
    data.packageDescription || '';

  this.pickupDate =
    data.pickupDate || '';

  this.preferredTime =
    data.preferredTime || '';

  this.remarks =
    data.remarks || '';

  this.surfaceLength =
    this.toNumber(data.surfaceLength);

  this.surfaceWidth =
    this.toNumber(data.surfaceWidth);

  this.surfaceHeight =
    this.toNumber(data.surfaceHeight);

  this.surfaceCFT =
    this.toNumber(data.surfaceCFT);

  this.airLength =
    this.toNumber(data.airLength);

  this.airWidth =
    this.toNumber(data.airWidth);

  this.airHeight =
    this.toNumber(data.airHeight);

  this.airCFT =
    this.toNumber(data.airCFT);

  if (data.pickup) {

    this.pickupContactName =
      data.pickup.contactName || '';

    this.pickupMobileNumber =
      data.pickup.mobileNumber || '';

    this.pickupCompanyName =
      data.pickup.companyName || '';

    this.pickupAddress =
      data.pickup.address || '';

    this.fromPincode =
      data.pickup.pincode || '';

    this.pickupCity =
      data.pickup.city || '';

    this.pickupState =
      data.pickup.state || '';

    this.pickupAddressDate =
      data.pickup.pickupDate || '';

    this.pickupTime =
      data.pickup.pickupTime || '';
  }

  if (data.delivery) {

    this.deliveryContactName =
      data.delivery.contactName || '';

    this.deliveryMobileNumber =
      data.delivery.mobileNumber || '';

    this.deliveryCompanyName =
      data.delivery.companyName || '';

    this.deliveryAddress =
      data.delivery.address || '';

    this.toPincode =
      data.delivery.pincode || '';

    this.deliveryCity =
      data.delivery.city || '';

    this.deliveryState =
      data.delivery.state || '';

    this.deliveryAddressDate =
      data.delivery.deliveryDate || '';

    this.deliveryTime =
      data.delivery.deliveryTime || '';
  }
}
  private buildLocation(city: string,pincode: string): string {
    const cityValue = city?.trim() ||'';
    const pincodeValue =pincode?.trim() ||'';
    if ( cityValue && pincodeValue) {
      return `${cityValue} (${pincodeValue})`;
    }
    return (cityValue ||pincodeValue ||''
    );
  }

  private getLocalStorageValue(keys: string[]): string {
    for (const key of keys) {
      const value = localStorage.getItem(key);
      if (value) {
        return value;
      }
    }
    return '';
  }


// private getServiceTypeName(serviceType: any): string {
//   const code = String(serviceType ?? '').trim();
//   switch (code) {
//     case '21':
//       return 'Surface';
//     case '23':
//       return 'Air';
//     case '24':
//       return 'Rail';
//     default:
//       return code;
//   }
// }

  // private getServiceCode(): string {
  //   switch (
  //     this.serviceType?.trim().toLowerCase()) {
  //     case 'surface':
  //     case 'surface express':
  //       return '21';
  //     case 'air':
  //     case 'air express':
  //       return '23';
  //     case 'rail':
  //     case 'rail express':
  //       return '24';
  //     default:
  //       throw new Error(
  //         'Invalid service type selected.'
  //       );
  //   }
  // }

//   get serviceTypeDisplay(): string {
//   switch (this.serviceType?.trim().toLowerCase()) {
//     case 'surface':
//     case 'surface express':
//       return 'Surface Express';

//     case 'air':
//     case 'air express':
//       return 'Air Express';

//     case 'rail':
//     case 'rail express':
//       return 'Rail Express';

//     default:
//       return 'Surface Express';
//   }
// }

private getServiceTypeName(serviceType: any): string {
  const code = String(serviceType ?? '').trim().toUpperCase();

  switch (code) {
    case '21':
    case 'SURFACE':
    case 'SURFACE EXPRESS':
      return 'Surface';

    case '22':
    case '23':
    case 'AIR':
    case 'AIR EXPRESS':
      return 'Air';

    case '24':
    case 'RAIL':
    case 'RAIL EXPRESS':
      return 'Rail';

    default:
      console.warn('Unknown service type:', serviceType);
      return '';
  }
}

get serviceTypeDisplay(): string {
  // Prefer the normalized serviceType because this is what
  // populateShipmentDetails() sets from the API response.
  switch (this.serviceType?.trim().toLowerCase()) {
    case 'surface':
    case 'surface express':
      return 'Surface Express';

    case 'air':
    case 'air express':
      return 'Air Express';

    case 'rail':
    case 'rail express':
      return 'Rail Express';

    default:
      // Fallback to API code
      switch (String(this.serviceTypeCode).trim()) {
        case '21':
          return 'Surface Express';

        case '22':
        case '23':
          return 'Air Express';

        case '24':
          return 'Rail Express';

        default:
          return 'Service Type';
      }
  }
}

private getServiceCode(): string {
  switch (this.serviceType?.trim().toLowerCase()) {
    case 'surface':
    case 'surface express':
      return '21';

    case 'air':
    case 'air express':
      return '22';

    case 'rail':
    case 'rail express':
      return '24';

    default:
      // Fallback to API code
      switch (String(this.serviceTypeCode).trim()) {
        case '21':
          return '21';

        case '22':
        case '23':
          return '22';

        case '24':
          return '24';

        default:
          throw new Error(
            `Invalid service type: ${this.serviceType}`
          );
      }
  }
}
  calculateFreight(): void {
    this.resetCalculationState();
    const validationError =this.validateBookingDetails();
    if (validationError) {
      this.errorMessage = validationError;
      return;
    }
    let serviceCode: string;
    try {
      serviceCode =this.getServiceCode();
    }
    catch (error: any) {
      this.errorMessage =error?.message ||'Invalid service type.';
      return;
    }
    const payload =this.buildFreightPayload( serviceCode);
    this.isCalculating = true;
    this.freightCalculatorService
      .calculateFreight(payload)
      .subscribe({next: (response: any) =>this.handleFreightSuccess( response),
        error: (error: any) =>
          this.handleFreightError( error
          )
      });
  }

  private resetCalculationState(): void {
    this.errorMessage = '';
    this.successMessage = '';
    this.freightCalculated = false;
    this.selectedCoupon = '';
    this.couponDiscount = 0;
    this.couponApplied = false;
    this.payableAmount = 0;

  }

  private validateBookingDetails(): string {
    if (!this.fromPincode) {return 'Pickup pincode is required.';}
    if (!this.toPincode) { return 'Destination pincode is required.';}
    if (!this.chargeableWeight ||this.chargeableWeight <= 0) {
      return 'Chargeable weight is required.'; }
    this.noOfPackages = 1;
    return '';
  }


  private buildFreightPayload(
    serviceCode: string ): Record<string, string> {
    return {
      pan_No:String(  this.panNo || ''),
      cust_mobile:String(this.custMobile || ''),
      imei_no: '',
      sim_no: '',
      bkg_branch: '',
      ba_code: '',
      cust_code: '',
      tbb_flag:String( this.tbbFlag || 'N'),
      basis:String( this.basis || '1'),
      mbg:String(this.mbg || 'N'),
      division_code:String(serviceCode),
      modes_of_tpt1:String(serviceCode),
      pincode:String( this.toPincode || ''),
      bkg_pincode:String(this.fromPincode || '' ),
      frt:String(this.frt || '100'),
      chgwt:String(this.chargeableWeight || 0),
      cod_amt: String(this.codAmount || 0),
      toT_PKGS: '1',
      declare_value:
        String(
          this.declaredValue || 0
        )
    };

  }

  private handleFreightSuccess(
    response: any): void {
    if (  response?.flag !== 'SUCCESS') {this.isCalculating = false;
       this.errorMessage = response?.message ||'Unable to calculate freight.';
      return;
    }
    const freightData =this.parseFreightResponse(
        response.final);
    if (!freightData) {
      this.isCalculating = false;
      this.errorMessage ='Invalid freight response received from server.';
      return;
    }
    this.mapFreightResponse( freightData);
    this.payableAmount =this.totalFreight;
    this.freightCalculated = this.totalFreight > 0;
    this.isCalculating = false;
    if (!this.freightCalculated) {
      this.errorMessage ='Freight amount returned as zero.';
      return;
    }
    this.successMessage ='Freight calculated successfully.';
    this.saveFreightAmount();
  }

 private parseFreightResponse(finalResponse: any): any | null {
    try {
      if (typeof finalResponse ==='string') {
        const parsed =JSON.parse( finalResponse );
        return Array.isArray(parsed)? parsed[0]: parsed;}
      if ( Array.isArray( finalResponse)
      ) { return ( finalResponse[0] ||null);}
      return (finalResponse ||null);
    }
    catch (error) {
      console.error('Freight Response Parse Error:',error);
      return null;
    }
  }

  private mapFreightResponse(data: any): void {
    this.baseFreight =this.toNumber(data.BASIC_FRT);
    this.fuelSurcharge =this.toNumber(  data.FUEL_CALC_CHARGE);
    this.deliveryProtection =this.toNumber( data.FOV_CHG);
    this.handlingCharge =this.toNumber(data.HAND_CHG);
    this.fodCharge =this.toNumber(data.FOD_CHG);
    this.codCharge =this.toNumber(  data.COD_CHG);
    this.odaCharge = this.toNumber(   data.ODA_CHG );
    this.miscCharge =this.toNumber(  data.MISC_CHG);
    this.odaDiscount =this.toNumber(  data.ODA_DISCOUNT);
    this.ngtCharge =this.toNumber(  data.NGT_CHG);
    this.sdcCharge = this.toNumber(  data.SDC_CHG);
    this.daccCharge =this.toNumber( data.DACC_CHG);
    this.fuelSurchargePercent =this.toNumber( data.FUEL_CHG );
    this.subtotal =this.toNumber(  data.SUBTOTAL_CHARGE);
    this.totalFreight =this.toNumber(  data.TOTAL_CHARGE);
  }

  private handleFreightError(error: any): void {
    console.error('Freight Calculator Error:',error);
    this.isCalculating = false;
    this.freightCalculated = false;
    this.errorMessage =error?.error?.message ||error?.message ||
      'Unable to calculate freight. Please try again.';
  }


  applyCoupon(): void {
    this.errorMessage = '';
    this.successMessage = '';
    this.couponError = '';
    if (!this.freightCalculated) {
      this.errorMessage ='Please calculate freight first.';
      return;
     }
    if (!this.selectedCoupon) {
      this.errorMessage ='Please select a coupon.';
      return;
    }
    const coupon =this.coupons.find( item =>  item.promoCode === this.selectedCoupon);
    if (!coupon) {
      this.errorMessage ='Invalid coupon selected.';
      return;
    }
    const today =new Date();
    const validUpto =
      new Date(coupon.validUpto);
    if (
      validUpto <today) {
      this.errorMessage ='This coupon has expired.';
      return;
    }
    this.couponDiscount =
      Math.min(
        this.toNumber( coupon.amount),
        this.toNumber(this.totalFreight)
      );

    this.payableAmount =
      Math.max( 0,
        this.toNumber( this.totalFreight) -
        this.couponDiscount
      );
    this.couponApplied = true;
    this.successMessage =`Coupon ${coupon.promoCode} applied successfully.`;
    this.saveCouponDetails();
  }


  removeCoupon(): void {
    this.selectedCoupon = '';
    this.couponDiscount = 0;
    this.couponApplied = false;
    this.payableAmount =this.totalFreight;
    this.successMessage ='Coupon removed successfully.';
    localStorage.removeItem('couponCode');
    localStorage.removeItem('couponDiscount');
    localStorage.setItem('payableAmount',this.payableAmount.toString());
  }


private saveFreightAmount(): void {
    localStorage.setItem('freightAmount',this.totalFreight.toString());
    localStorage.setItem('totalFreight',this.totalFreight.toString());
    localStorage.setItem('payableAmount',this.totalFreight.toString());
    localStorage.setItem('freightCalculated','true');
}

private saveCouponDetails(): void {
    localStorage.setItem('payableAmount',this.payableAmount.toString());
    localStorage.setItem( 'couponCode', this.selectedCoupon);
    localStorage.setItem('couponDiscount', this.couponDiscount.toString());
}

proceedToPayment(): void {
    if (this.isPaying) {
      return;}
    if (!this.freightCalculated) {
      this.errorMessage ='Please calculate freight before proceeding to payment.';
      return;
    }
    const amount =this.toNumber( this.payableAmount);
    if (amount <= 0) {this.errorMessage ='Invalid payment amount.';return;}
    const txnId = this.getLocalStorageValue(['bookingOrderId','orderId','txnId','ORDER_ID','orderID']);
    if (!txnId) {
      this.errorMessage ='Order ID not found. Please complete the booking details first.';
      console.error('PayU Error: Order ID is missing from localStorage.');
      return;
    }
    const payload = {txnId: txnId,amount: amount.toFixed(2),productInfo:'TCI Express Online Booking'};
    this.isPaying = true;
    this.errorMessage = '';
    this.successMessage = 'Initializing payment...';
    this.paymentService.initiatePayment(payload)
    .subscribe({
        next: (response: any) => {
          if (
            !response?.success || !response?.data
          ) {
            this.isPaying = false;
            this.successMessage = '';
            this.errorMessage =response?.message ||'Unable to initialize payment.';
            return;
          }
          this.savePaymentDetails(amount,response.data
          );
          try {
            this.paymentService
              .submitToPayU(
                response.paymentUrl,
                response.data
              );
          }
          catch (error) {
            console.error(
              'PayU form submission error:',
              error
            );
            this.isPaying = false;
            this.successMessage = '';
            this.errorMessage =
              'Unable to redirect to PayU.';
          }
        },
        error: (error: any) => {
          this.isPaying = false;
          this.successMessage = '';
          console.error(
            'Payment API Error:',
            error
          );
          this.errorMessage =
            error?.error?.message ||
            error?.message ||
            'Unable to connect to payment gateway. Please try again.';
        }
      });
  }

  private savePaymentDetails( amount: number, paymentData: PayUData): void {
    localStorage.setItem('paymentAmount', amount.toFixed(2));
    if (paymentData?.txnid) {
    localStorage.setItem('payuTxnId',paymentData.txnid);}
    localStorage.setItem( 'paymentStatus','PENDING');
  }


  private extractPincode(location: string): string {
    if (!location) { return '';}
    const match =location.match(  /\b\d{6}\b/);
    return match? match[0]: '';
  }

  private toNumber( value: any ): number {
    const numberValue = Number(value);
    return Number.isFinite( numberValue)
      ? numberValue
      : 0;
  }


  goBack(): void {
    this.location.back();
  }

}
