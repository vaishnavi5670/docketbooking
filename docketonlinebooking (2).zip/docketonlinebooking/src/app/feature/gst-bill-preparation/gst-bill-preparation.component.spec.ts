import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GstBillPreparationComponent } from './gst-bill-preparation.component';

describe('GstBillPreparationComponent', () => {
  let component: GstBillPreparationComponent;
  let fixture: ComponentFixture<GstBillPreparationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GstBillPreparationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GstBillPreparationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
