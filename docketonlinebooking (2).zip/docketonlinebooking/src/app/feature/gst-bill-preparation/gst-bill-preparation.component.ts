import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { RouterLink } from '@angular/router';
@Component({
  selector: 'app-gst-bill-preparation',
  standalone: true,
  imports: [BookingShellComponent,FormsModule, RouterLink],
  templateUrl: './gst-bill-preparation.component.html',
  styleUrl: './gst-bill-preparation.component.css'
})
export class GstBillPreparationComponent {
  billType = 'Tax Invoice (GST)';

  placeOfSupply = 'Maharashtra (27)';
}
