import {ChangeDetectionStrategy,ChangeDetectorRef,Component,DestroyRef,OnDestroy,inject} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AuthService } from '../../services/auth.service';

type LoginResponse = {
  success: boolean;
  otpRequired?: boolean;
  userId?: number | string;
  mobileNo?: string;
  message?: string;
};

type VerifyOtpResponse = {
  success: boolean;
  message?: string;
};

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnDestroy {

  private readonly destroyRef = inject(DestroyRef);

  private readonly STORAGE = {
    bookingUserId: 'bookingUserId',
    userId: 'userId',
    mobileNo: 'mobileNo',
    bookingMobile: 'bookingMobile',
    isLoggedIn: 'isLoggedIn',

    activeBookingUserId: 'activeBookingUserId',
    activeBookingMobileNo: 'activeBookingMobileNo',
    bookingSessionActive: 'bookingSessionActive',

    bookingOrderId: 'bookingOrderId',
    orderId: 'orderId',

    pickupAddress: 'tci_booking_pickup_address',
    deliveryAddress: 'tci_booking_delivery_address',

    pickupPincode: 'pickupPincode',
    deliveryPincode: 'deliveryPincode',
    pickupCity: 'pickupCity',
    pickupState: 'pickupState',
    pickupLocation: 'pickupLocation',
    pickupBranchCode: 'pickupBranchCode',

    deliveryCity: 'deliveryCity',
    deliveryState: 'deliveryState',
    deliveryLocation: 'deliveryLocation',
    deliveryBranchCode: 'deliveryBranchCode',

    shipmentData: 'shipmentData',
    legacyShipmentData: 'tci_shipment_data'
  } as const;

  mobile = '';
  otp = '';
  loginError = '';
  isOtpSent = false;
  isSendingOtp = false;
  isVerifyingOtp = false;
  resendTimer = 0;

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  private readonly MOBILE_REGEX = /^[6-9]\d{9}$/;
  private readonly OTP_REGEX = /^\d{6}$/;

  constructor(private readonly router: Router,private readonly authService: AuthService,private readonly cdr: ChangeDetectorRef) {}

  sendOtp(): void {
    if (this.isSendingOtp || this.isVerifyingOtp) {
      return;
    }
    this.loginError = '';
    const mobile = this.mobile.replace(/\D/g, '');
    if (!this.MOBILE_REGEX.test(mobile)) {
      this.loginError = 'Please enter a valid 10-digit mobile number.';
      this.markForCheck();
      return;
    }
    this.mobile = mobile;
    this.isSendingOtp = true;
    this.authService.login(mobile)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.isSendingOtp = false;
          this.markForCheck();
        })
      )
      .subscribe({
        next: (response: LoginResponse) => {
          if (!response?.success || !response.otpRequired) {
            this.loginError =
              response?.message || 'Unable to send OTP.';
            return;
          }
          const responseMobile = String(response.mobileNo ?? mobile);
          const userId = String(response.userId ?? '');
          if (!this.MOBILE_REGEX.test(responseMobile)) {
            this.loginError =
              'The server returned an invalid mobile number.';
            return;
          }
          if (!userId || !/^\d+$/.test(userId)) {
            this.loginError =
              'Unable to identify your account. Please try again.';
            return;
          }
          this.mobile = responseMobile;
          this.isOtpSent = true;
          this.setStorage(this.STORAGE.bookingUserId, userId);
          this.setStorage(this.STORAGE.userId, userId);
          this.setStorage(this.STORAGE.bookingMobile, responseMobile);
          this.setStorage(this.STORAGE.mobileNo, responseMobile);
          this.otp = '';
          this.startResendTimer();
        },
        error: (error) => {
          this.loginError =
            error?.error?.message ||
            'Unable to send OTP. Please try again.';
        }
      });
  }


  verifyOtp(): void {
    if (this.isVerifyingOtp || this.isSendingOtp) {
      return;
    }
    this.loginError = '';
    const mobile = this.mobile.replace(/\D/g, '');
    const otp = this.otp.trim();
    if (!this.MOBILE_REGEX.test(mobile)) {
      this.loginError = 'Please enter a valid 10-digit mobile number.';
      this.markForCheck();
      return;
    }
    if (!this.OTP_REGEX.test(otp)) {
      this.loginError = 'Please enter a valid 6-digit OTP.';
      this.markForCheck();
      return;
    }
    const userId = localStorage.getItem(this.STORAGE.bookingUserId);
    if (!userId || !/^\d+$/.test(userId)) {
      this.loginError =
        'Your login session has expired. Please request a new OTP.';
      this.isOtpSent = false;
      this.markForCheck();
      return;
    }
    this.isVerifyingOtp = true;
    this.authService.verifyOtp(mobile, otp)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.isVerifyingOtp = false;
          this.markForCheck();
        })
      )
      .subscribe({
        next: (response: VerifyOtpResponse) => {
          if (!response?.success) {
            this.loginError = response?.message || 'Invalid OTP.';
            return;
          }

          const newUserId = userId;
          const newMobile = mobile;

          this.handlePreviousBookingSession(newUserId, newMobile);
          this.saveLoggedInUser(newUserId, newMobile);
          this.startNewBookingSession(newUserId, newMobile);
          this.clearOtpTimer();
          this.router.navigate(['/service-check']);
        },

        error: (error) => {
          this.loginError =
            error?.status === 401
              ? 'Invalid OTP. Please enter the latest OTP received.'
              : error?.error?.message ||
                'OTP verification failed. Please try again.';
        }
      });
  }


  private handlePreviousBookingSession(
    newUserId: string,
    newMobile: string): void {
    const previousUserId = localStorage.getItem(this.STORAGE.activeBookingUserId);
    const previousMobile = localStorage.getItem(this.STORAGE.activeBookingMobileNo);
    const sessionActive =localStorage.getItem(this.STORAGE.bookingSessionActive) === 'true';
    const differentUser = !!previousUserId && previousUserId !== newUserId;
    const differentMobile =!!previousMobile && previousMobile !== newMobile;
    if (sessionActive && (differentUser || differentMobile)) {
      this.clearPreviousBookingSession();
    }
  }

  private clearPreviousBookingSession(): void {
    const keysToRemove: readonly string[] = [
      this.STORAGE.activeBookingUserId,
      this.STORAGE.activeBookingMobileNo,
      this.STORAGE.bookingSessionActive,
      this.STORAGE.bookingOrderId,
      this.STORAGE.orderId,
      this.STORAGE.pickupAddress,
      this.STORAGE.deliveryAddress,
      this.STORAGE.pickupPincode,
      this.STORAGE.deliveryPincode,
      this.STORAGE.pickupCity,
      this.STORAGE.pickupState,
      this.STORAGE.pickupLocation,
      this.STORAGE.pickupBranchCode,
      this.STORAGE.deliveryCity,
      this.STORAGE.deliveryState,
      this.STORAGE.deliveryLocation,
      this.STORAGE.deliveryBranchCode,
      this.STORAGE.shipmentData,
      this.STORAGE.legacyShipmentData,
      'tci_active_booking_session',
      'tci_active_booking_session_user'
    ];
    keysToRemove.forEach(key => localStorage.removeItem(key));
  }

  private saveLoggedInUser(userId: string,mobile: string): void {
    this.setStorage(this.STORAGE.isLoggedIn, 'true');
    this.setStorage(this.STORAGE.bookingUserId, userId);
    this.setStorage(this.STORAGE.userId, userId);
    this.setStorage(this.STORAGE.mobileNo, mobile);
    this.setStorage(this.STORAGE.bookingMobile, mobile);
  }


  private startNewBookingSession(userId: string, mobile: string): void {
    this.setStorage(this.STORAGE.activeBookingUserId, userId);
    this.setStorage(this.STORAGE.activeBookingMobileNo, mobile);
    this.setStorage(this.STORAGE.bookingSessionActive, 'true');

    const sessionId = `${userId}_${Date.now()}`;
    this.setStorage('tci_active_booking_session', sessionId);
    this.setStorage('tci_active_booking_session_user', userId);
  }


  resendOtp(): void {
    if (this.resendTimer > 0 ||this.isSendingOtp ||this.isVerifyingOtp) {
      return;
    }
    this.sendOtp();
  }


  startResendTimer(): void {
    this.clearOtpTimer();
    this.resendTimer = 30;
    this.timerInterval = setInterval(() => {
      if (this.resendTimer > 0) {
        this.resendTimer--;
      }
      if (this.resendTimer <= 0) {
        this.clearOtpTimer();
      }
      this.markForCheck();
    }, 1000);
    this.markForCheck();
  }
  get formattedTimer(): string {
    const minutes = Math.floor(this.resendTimer / 60)
      .toString()
      .padStart(2, '0');
    const seconds = (this.resendTimer % 60)
      .toString()
      .padStart(2, '0');
    return `${minutes}:${seconds}`;
  }

  private clearOtpTimer(): void {
    if (this.timerInterval !== null) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;}
    this.resendTimer = 0;
  }


  private setStorage(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
    }
  }


  private markForCheck(): void {
    this.cdr.markForCheck();
  }

  ngOnDestroy(): void {
    this.clearOtpTimer();
  }
}
