export interface RegisterModel {
  firstName: string;
  lastName: string;
  mobile: string;
  email: string;
  companyName: string;
  password: string;
  confirmPassword: string;
  consent: boolean;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  mobileNo: string;
  email: string;
  companyName?: string;
  password: string;
}

export interface Address {
 contactName: string;
  mobile: string;
  pickupEmail: string;
  deliveryEmail: string;
  companyName: string;
  address: string;
  pincode: string;
  city: string;
  state: string;
  pickupLandmark: string;
  deliveryLandmark: string;
  saveAddress: boolean;
  type: 'pickup' | 'delivery' | 'both';
  pickupDate?: string;
  pickupTime?: string;
  deliveryDate?: string;
  deliveryTime?: string;
}

export interface PinCodeLocation {
  pincode: string;
  city: string;
  state: string;
  location: string;
  branchCode: string;

}

export interface PinCodeCheckResponse {
  success: boolean;
  message: string;
  serviceAvailable: boolean;
  pickup: PinCodeLocation;
  delivery: PinCodeLocation;

}
export interface PinCodeCheckRequest {
  pickupPincode: string;
  deliveryPincode: string;
}
export interface ShipmentSaveRequest {
  serviceType: string;
  shipmentType: string;
  noOfPackages: number;
  materialItem: string;
  pickupDate: string;
  preferredTime: string;
  remarks: string;

  actualWeight: number;
  volumetricCFT: number;
  chargeableWeight: number;

  packageContentType: string;
  packageDescription: string;
  declaredValue: number;

  surfaceLength: number;
  surfaceWidth: number;
  surfaceHeight: number;
  surfaceCFT: number;

  airLength: number;
  airWidth: number;
  airHeight: number;
  airCFT: number;
}
export interface ShipmentGetResponse {
  success: boolean;
  message: string;
  data: ShipmentDetails;
}
export interface ShipmentDetails {
  id: number;
  serviceType: string;
  shipmentType: string;
  noOfPackages: number;
  materialItem: string;
  pickupDate: string;
  preferredTime: string;
  remarks: string;
  actualWeight: number;
  volumetricCFT: number;
  chargeableWeight: number;
  packageContentType: string;
  packageDescription: string;
  declaredValue: number;
  surfaceLength: number;
  surfaceWidth: number;
  surfaceHeight: number;
  surfaceCFT: number;
  airLength: number;
  airWidth: number;
  airHeight: number;
  airCFT: number;
  createdDate: string;
}
export interface FreightCalculatorRequest {
  pan_No: string;
  imei_no: string;
  sim_no: string;
  bkg_branch: string;
  ba_code: string;
  tbb_flag: string;
  cust_code: string;
  basis: string;
  division_code: string;
  pincode: string;
  frt: string;
  chgwt: string;
  cod_amt: string;
  toT_PKGS: string;
  declare_value: string;
  mbg: string;
  modes_of_tpt1: string;
  bkg_pincode: string;
  cust_mobile: string;
}
export interface LoginRequest {
  MobileNO: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  otpRequired: boolean;
  MobileNO: string;
  userId: number;
}
export interface RegisterResponse {
  success: boolean;
  message: string;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  mobileNo: string;
  email: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
}

export interface PayURequest {
  txnId: string;
  amount: string;
  productInfo: string;
}

export interface PayUData {
  key: string;
  txnid: string;
  amount: string;
  productinfo: string;
  firstname: string;
  email: string;
  phone: string;
  surl: string;
  furl: string;
  hash: string;
  udf1: string;
  udf2: string;
  udf3: string;
  udf4: string;
  udf5: string;
  service_provider: string;
}


export interface PayUResponse {
  success: boolean;
  message?: string;
  paymentUrl: string;
  data: PayUData;

}
export interface SaveShipmentRequest {
  userId: number;
  orderId: string;
  serviceType: string;

  noOfPackages: 1;
  materialItem: string;
  pickupDate: string;
  preferredTime: string;
  remarks: string;
  actualWeight: number;
  volumetricCFT: number;
  chargeableWeight: number;
  packageContentType: string;
  packageDescription: string;
  declaredValue: number;
  surfaceLength: number;
  surfaceWidth: number;
  surfaceHeight: number;
  surfaceCFT: number;
  airLength: number;
  airWidth: number;
  airHeight: number;
  airCFT: number;
}

export interface CheckBookingDateRequest {
  pickupDate: string;
  pickupPincode: string;
}

export interface CheckBookingDateResponse {
  status: boolean;
  message: string;
  pickupDate: string;
  pickupPincode: string;
  bookingDate: string;
}

export interface VerificationResponse {
  success: boolean;
  message: string;
  data?: string;
}
export interface SavePanGstRequest {
  userId: number;
  mobileNo: string;
  customerType: string;
  panNumber: string;
  gstNumber: string;
}

export interface SavePanGstResponse {
  success: boolean;
  message: string;
  data?: {
    mobileNo: string;
    customerType: string;
    panNumber: string;
    gstNumber: string | null;
    userId: number;
    verified: boolean;
  };
}
export interface PaymentSuccessWebhookRequest {
  pickupReferenceNumber: string;
  bankReferenceNumber: string;
  serviceType: string;
  pickupDate: string; origin: string; destination: string; customerName: string; mobileNumber: string; }

  export interface PaymentSuccessWebhookResponse {
     success: boolean; message: string; data?: { pickupReferenceNumber: string; bankReferenceNumber: string; serviceType: string; pickupDate: string; origin: string; destination: string; pdfUrl: string | null; whatsApp?: { sent: boolean; messageId: string | null; }; }; }
