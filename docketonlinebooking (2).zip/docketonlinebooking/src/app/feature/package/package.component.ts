import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { ShipmentService } from '../../services/shipment.service';
import { SaveShipmentRequest } from '../models/onlinebooking.model';

@Component({
  selector: 'app-package',
  standalone: true,
  imports: [CommonModule, FormsModule, BookingShellComponent],
  templateUrl: './package.component.html',
  styleUrl: './package.component.css'
})
export class PackageComponent implements OnInit {

  activeStep = 2;

  isSaving = false;
  isLoading = false;
  errorMessage = '';
  successMessage = '';
  shipmentApiError = '';
  serviceType = 'Surface Express';
  numberOfPackages = 1;
  materialType = '';
  pickupDate = '';
  preferredTime = 'Any Time';
  remarks = '';
  today = '';
  maxPickupDate = '';
  checkingPickupDate = false;
  pickupDateError = '';
  actualWeight = 0;
  volumetricCft = 0;
  chargeableWeight = 0;
  packageContentType = '';
  packageDescription = '';
  declaredValue = 0;
  length: number | null = null;
  breadth: number | null = null;
  height: number | null = null;
  isVolumetricDisabled = true;
  pickupCity = '';
  pickupPincode = '';
  deliveryCity = '';
  deliveryPincode = '';
  shipmentImage: File | null = null;
  shipmentImagePreview: string | null = null;
  shipmentImageName = '';
  freightAmount = 0;
  isCalculatingFreight = false;
  freightError = '';
  isRestrictedMaterial = false;
  holidayDates: string[] = [];
  isCheckingHolidayDates = false;
  validationErrors: { [key: string]: string } = {};
  submitted = false;


  private readonly shipmentStorageKey = 'tci_booking_shipment_data';
  private readonly bookingSessionKey = 'tci_active_booking_session';
  private readonly bookingSessionUserKey = 'tci_active_booking_session_user';

  constructor( private readonly shipmentService: ShipmentService, private readonly router: Router, private readonly cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.serviceType = 'Surface Express';
    this.numberOfPackages = 1;
    this.preferredTime = 'Any Time';

    const userId = this.getLoggedInUserId();
    const sessionId = this.getBookingSessionId();

    this.setPickupDateRange();
    this.loadLocationData();

    const restored = this.loadShipmentDataLocally();
    if (restored) {
      this.cdr.markForCheck();
      return;
    }
    this.clearShipmentForm();
    this.cdr.markForCheck();
  }


  private getLoggedInUserId(): number | null {
    const storedUserId = localStorage.getItem('bookingUserId');
    if (!storedUserId) {
      return null;
    }
    const userId = Number(storedUserId);
    if (!Number.isInteger(userId) || userId <= 0) {
      return null;
    }
    return userId;
  }

private getBookingSessionId(): string {
    return (
      localStorage.getItem(this.bookingSessionKey) || ''
    ).trim();
  }

private getBookingSessionUserId(): string {
    return (
      localStorage.getItem(this.bookingSessionUserKey) || ''
    ).trim();
  }

private getBookingOrderId(): string {
    return (
      localStorage.getItem('bookingOrderId') ||
      localStorage.getItem('orderId') ||
      ''
    ).trim();
}



onPickupDateChange(): void {
  this.pickupDateError = '';
  if (!this.pickupDate) {
    this.validateField('pickupDate');
    this.cdr.markForCheck();
    return;
  }
  const today = new Date();
  const todayString = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  if (this.pickupDate === todayString) {
    this.pickupDateError ='Pickup cannot be booked for today. Please select another date.';
    this.pickupDate = '';
    this.cdr.markForCheck();
    return;
  }
  let pickupPincode = (this.pickupPincode || '').trim();
  const userId =localStorage.getItem('activeBookingUserId') ||localStorage.getItem('bookingUserId');
  const sessionId = localStorage.getItem('tci_active_booking_session');
  const sessionUserId = localStorage.getItem('tci_active_booking_session_user');
  if ( !pickupPincode && userId && sessionId && sessionUserId === userId
  ) {
    const pickupAddressKey =`tci_booking_pickup_address_${userId}_${sessionId}`;
    const pickupAddressData =localStorage.getItem(pickupAddressKey);
    if (pickupAddressData) {
      try {
        const pickupAddress = JSON.parse(pickupAddressData);
        pickupPincode = (
          pickupAddress?.pincode ||
          pickupAddress?.pickupPincode ||
          ''
        ).toString().trim();
      } catch (error) {
        console.error(
          'Error parsing pickup address:',
          error
        );
      }
    }
  }
  if (!pickupPincode) {
    pickupPincode = (
      localStorage.getItem('serviceCheckPickupPincode') ||
      localStorage.getItem('pickupPincode') ||
      localStorage.getItem('pickupPincodeStorage') ||
      ''
    ).trim();
  }
  if (!/^\d{6}$/.test(pickupPincode)) {
    this.pickupDateError ='Valid pickup pincode is required to check pickup date availability.';
    this.cdr.markForCheck();
    return;
  }
  this.pickupPincode = pickupPincode;
  const selectedDate = this.pickupDate;
  const apiPickupDate =this.convertDateToApiFormat(selectedDate);
  const request = { pickupDate: apiPickupDate, pickupPincode: pickupPincode};
  this.checkingPickupDate = true;
  this.cdr.markForCheck();
  this.shipmentService.checkBookingDate(request).subscribe({
    next: (response: any) => {
      this.checkingPickupDate = false;
      const bookingDates: string[] =
        Array.isArray(response?.bookingDates)
          ? response.bookingDates
          : [];
      const selectedApiDate =this.convertDateToBookingDateFormat(selectedDate);
      const isNonServiceable =
        bookingDates.some(
          (date: string) =>
            date?.trim().toUpperCase() ===
            selectedApiDate.toUpperCase()
        );
      if (isNonServiceable) {
        this.pickupDateError ='This date is not serviceable. Please select another date.';
        this.pickupDate = '';
        this.cdr.markForCheck();
        return;
      }
      this.pickupDate = selectedDate;
      this.pickupDateError = '';
      this.validateField('pickupDate');
      this.cdr.markForCheck();
    },
    error: (error: any) => {
      console.error(
        'CheckBookingDate API Error:',
        error
      );
      this.checkingPickupDate = false;
      this.pickupDate = selectedDate;
      this.pickupDateError =
        error?.error?.message ||
        error?.message ||
        'Unable to check pickup date availability. Please try again.';
      this.cdr.markForCheck();
    }
  });
}

  private convertDateToBookingDateFormat(date: string): string {

    const [year, month, day] = date.split('-');

    const months = [
      'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
      'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
    ];

    const monthName =
      months[Number(month) - 1];

    const shortYear =
      year.substring(2);

    return `${day}-${monthName}-${shortYear}`;
  }

  private convertDateToApiFormat(dateValue: string): string {

    const [year, month, day] =
      dateValue.split('-');

    const months = [
      'jan', 'feb', 'mar', 'apr',
      'may', 'jun', 'jul', 'aug',
      'sep', 'oct', 'nov', 'dec'
    ];

    return `${day}-${months[Number(month) - 1]}-${year}`;
  }

  // =========================================================
  // STORAGE KEY
  // =========================================================

  private getShipmentStorageKey(): string {

    const userId =
      this.getLoggedInUserId();

    const sessionId =
      this.getBookingSessionId();

    const sessionUserId =
      this.getBookingSessionUserId();

    if (!userId || !sessionId || !sessionUserId) {

      console.warn(
        'Unable to create session-based shipment storage key.',
        {
          userId,
          sessionId,
          sessionUserId
        }
      );

      return '';
    }

    if (
      String(userId) !==
      String(sessionUserId)
    ) {

      console.warn(
        'Booking session belongs to another user.'
      );

      return '';
    }

    return `${this.shipmentStorageKey}_${userId}_${sessionId}`;
  }

  // =========================================================
  // LOCATION DATA
  // =========================================================

  private loadLocationData(): void {

    const userId =
      this.getLoggedInUserId();

    const sessionId =
      this.getBookingSessionId();

    const sessionUserId =
      this.getBookingSessionUserId();

    let pickupPincode = '';
    let deliveryPincode = '';

    let pickupCity = '';
    let deliveryCity = '';

    if (
      userId &&
      sessionId &&
      String(userId) === String(sessionUserId)
    ) {

      const pickupKey =
        `tci_booking_pickup_address_${userId}_${sessionId}`;

      const deliveryKey =
        `tci_booking_delivery_address_${userId}_${sessionId}`;

      try {

        const pickupData =
          localStorage.getItem(pickupKey);

        const deliveryData =
          localStorage.getItem(deliveryKey);

        if (pickupData) {

          const address =
            JSON.parse(pickupData);

          pickupPincode =
            address.pincode ||
            address.pickupPincode ||
            '';

          pickupCity =
            address.city ||
            address.pickupCity ||
            '';
        }

        if (deliveryData) {

          const address =
            JSON.parse(deliveryData);

          deliveryPincode =
            address.pincode ||
            address.deliveryPincode ||
            '';

          deliveryCity =
            address.city ||
            address.deliveryCity ||
            '';
        }

      } catch (error) {

        console.error(
          'Unable to load session address:',
          error
        );
      }
    }

    if (!pickupPincode) {

      pickupPincode =
        localStorage.getItem('pickupPincode') ||
        localStorage.getItem('serviceCheckPickupPincode') ||
        localStorage.getItem('pickupPincodeStorage') ||
        '';
    }

    if (!deliveryPincode) {

      deliveryPincode =
        localStorage.getItem('deliveryPincode') ||
        localStorage.getItem('serviceCheckDeliveryPincode') ||
        localStorage.getItem('deliveryPincodeStorage') ||
        '';
    }

    if (!pickupCity) {
      pickupCity =
        localStorage.getItem('pickupCity') || '';
    }

    if (!deliveryCity) {
      deliveryCity =
        localStorage.getItem('deliveryCity') || '';
    }

    this.pickupPincode =
      String(pickupPincode).trim();

    this.deliveryPincode =
      String(deliveryPincode).trim();

    this.pickupCity =
      String(pickupCity).trim();

    this.deliveryCity =
      String(deliveryCity).trim();
  }

  // =========================================================
  // LOCAL SAVE
  // =========================================================

  private saveShipmentDataLocally(): void {

    const storageKey =
      this.getShipmentStorageKey();

    if (!storageKey) {
      return;
    }

    const userId =
      this.getLoggedInUserId();

    const sessionId =
      this.getBookingSessionId();

    const shipmentData = {

      userId,
      sessionId,

      orderId:
        this.getBookingOrderId(),

      serviceType:
        this.serviceType,



      numberOfPackages:
        this.numberOfPackages,

      materialType:
        this.materialType,

      pickupDate:
        this.pickupDate,

      preferredTime:
        this.preferredTime,

      remarks:
        this.remarks,

      actualWeight:
        this.actualWeight,

      volumetricCft:
        this.volumetricCft,

      chargeableWeight:
        this.chargeableWeight,

      packageContentType:
        this.packageContentType,

      packageDescription:
        this.packageDescription,

      declaredValue:
        this.declaredValue,

      length:
        this.length,

      breadth:
        this.breadth,

      height:
        this.height,

      isVolumetricDisabled:
        this.isVolumetricDisabled,

      pickupCity:
        this.pickupCity,

      pickupPincode:
        this.pickupPincode,

      deliveryCity:
        this.deliveryCity,

      deliveryPincode:
        this.deliveryPincode,

      shipmentImageName:
        this.shipmentImageName,

      savedAt:
        new Date().toISOString()
    };

    try {

      localStorage.setItem(
        storageKey,
        JSON.stringify(shipmentData)
      );

    } catch (error) {

      console.error(
        'Unable to save package data locally:',
        error
      );
    }
  }

  // =========================================================
  // LOAD LOCAL DATA
  // =========================================================

  private loadShipmentDataLocally(): boolean {

    const storageKey = this.getShipmentStorageKey();
    if (!storageKey) {
      return false;
    }
    const storedData =localStorage.getItem(storageKey);

    if (!storedData) {
      return false;
    }

    try {

      const data =
        JSON.parse(storedData);

      const currentUserId =
        this.getLoggedInUserId();

      if (
        data.userId &&
        currentUserId &&
        String(data.userId) !==
        String(currentUserId)
      ) {
        return false;
      }

      const currentSessionId =
        this.getBookingSessionId();

      if (
        data.sessionId &&
        currentSessionId &&
        String(data.sessionId) !==
        String(currentSessionId)
      ) {
        return false;
      }

      this.serviceType =
        data.serviceType || 'Surface Express';

      ;

      this.numberOfPackages =
        data.numberOfPackages
          ? Number(data.numberOfPackages)
          : 1;

      this.materialType =
        data.materialType || '';

      this.pickupDate =
        data.pickupDate || '';

      this.preferredTime =
        data.preferredTime || 'Any Time';

      this.remarks =
        data.remarks || '';

      this.actualWeight =
        Number(data.actualWeight) || 0;

      this.volumetricCft =
        Number(data.volumetricCft) || 0;

      this.chargeableWeight =
        Number(data.chargeableWeight) || 0;

      this.packageContentType =
        data.packageContentType || '';

      this.packageDescription =
        data.packageDescription || '';

      this.declaredValue =
        Number(data.declaredValue) || 0;

      this.length =
        data.length !== null &&
        data.length !== undefined
          ? Number(data.length)
          : null;

      this.breadth =
        data.breadth !== null &&
        data.breadth !== undefined
          ? Number(data.breadth)
          : null;

      this.height =
        data.height !== null &&
        data.height !== undefined
          ? Number(data.height)
          : null;

      this.isVolumetricDisabled =
        this.actualWeight <= 2;

      this.pickupPincode =
        this.pickupPincode ||
        data.pickupPincode ||
        '';

      this.deliveryPincode =
        this.deliveryPincode ||
        data.deliveryPincode ||
        '';

      this.pickupCity =
        localStorage.getItem('pickupCity') ||
        data.pickupCity ||
        '';

      this.deliveryCity =
        localStorage.getItem('deliveryCity') ||
        data.deliveryCity ||
        '';

      this.shipmentImageName =
        data.shipmentImageName || '';

      // File itself cannot be restored from localStorage.
      this.shipmentImage = null;
      this.shipmentImagePreview = null;

      return true;

    } catch (error) {

      console.error(
        'Error parsing shipment localStorage:',
        error
      );

      return false;
    }
  }

  // =========================================================
  // CLEAR FORM
  // =========================================================

  private clearShipmentForm(): void {

    this.actualWeight = 0;
    this.volumetricCft = 0;
    this.chargeableWeight = 0;
    this.declaredValue = 0;
    this.serviceType = 'Surface Express';
    this.numberOfPackages = 1;
    this.materialType = '';
    this.pickupDate = '';
    this.preferredTime = 'Any Time';
    this.remarks = '';
    this.packageContentType = '';
    this.packageDescription = '';
    this.length = null;
    this.breadth = null;
    this.height = null;
    this.isVolumetricDisabled = true;
    this.shipmentImage = null;
    this.shipmentImagePreview = null;
    this.shipmentImageName = '';
    this.validationErrors = {};
    this.submitted = false;
    this.isLoading = false;
  }

  // =========================================================
  // PACKAGE COUNT
  // =========================================================

  decreasePackages(): void {
    if (this.numberOfPackages > 1) {
      this.numberOfPackages--;
      this.saveShipmentDataLocally();
    }
  }

  increasePackages(): void {
    this.numberOfPackages++;
    this.saveShipmentDataLocally();
  }

  // =========================================================
  // MATERIAL
  // =========================================================

  onMaterialTypeChange(): void {
    const restrictedMaterials = ['Flammable','Liquids / Gas','Batteries','Biohazard','Explosives'];
    this.isRestrictedMaterial =
      restrictedMaterials.includes(
        this.materialType
      );
    this.validateField('materialType');
  }

  // =========================================================
  // WEIGHT
  // =========================================================

  onWeightChange(): void {
    const enteredWeight = Number(this.actualWeight) || 0;
    this.actualWeight =Math.ceil( Math.max(0, enteredWeight));
    this.isVolumetricDisabled =this.actualWeight <= 2;
    if (this.isVolumetricDisabled) {
      this.volumetricCft = 0;
      this.chargeableWeight = this.actualWeight;
      this.length = null;
      this.breadth = null;
      this.height = null;
      this.removeShipmentImage();
    } else {
      this.calculateVolumetric();
    }
    if (this.submitted) {
      this.validateShipmentForm();
    }
    this.cdr.markForCheck();
  }

  // =========================================================
  // VOLUMETRIC CALCULATION
  // =========================================================

  calculateVolumetric(): void {

    const weight =
      Number(this.actualWeight) || 0;
    if (weight <= 2) {
      this.volumetricCft = 0;
      this.chargeableWeight = weight;
      this.isVolumetricDisabled = true;
      return;
  }

    this.isVolumetricDisabled = false;

    const length =
      Number(this.length) || 0;

    const breadth =
      Number(this.breadth) || 0;

    const height =
      Number(this.height) || 0;
    if (
      length <= 0 ||
      breadth <= 0 ||
      height <= 0
    ) {
      this.volumetricCft = 0;
      this.chargeableWeight = 0;
      return;
    }

    const divisor =
      this.getVolumetricDivisor();

   const volumetricWeight = Number(((length * breadth * height) / divisor).toFixed(2));
    this.volumetricCft = volumetricWeight;
    this.chargeableWeight =Math.max( weight, this.volumetricCft);
  }

  private getVolumetricDivisor(): number {

    switch (this.serviceType) {
      case 'Air Express':
      case 'Air':
        return 366;

      case 'Surface Express':
      case 'Surface':
        return 1728;

      case 'Rail Express':
      case 'Rail':
        return 1728;

      default:
        return 1728;
    }
  }

  // =========================================================
  // SERVICE TYPE
  // =========================================================

  onServiceTypeChange(): void {
    this.calculateVolumetric();
    this.freightAmount = 0;
    this.freightError = '';
    if (this.submitted) {
      this.validateShipmentForm();
    }
    this.saveShipmentDataLocally();
    this.cdr.markForCheck();
  }

  // =========================================================
  // DIMENSION CHANGE
  // =========================================================

  onDimensionChange(): void {

    this.calculateVolumetric();

    if (this.submitted) {
      this.validateShipmentForm();
    }

    this.cdr.markForCheck();
  }

  // =========================================================
  // IMAGE
  // =========================================================

  onShipmentImageSelected(event: Event): void {

    const input =
      event.target as HTMLInputElement;

    if (
      !input.files ||
      input.files.length === 0
    ) {
      return;
    }

    const file =
      input.files[0];

    const allowedTypes = [
      'image/jpeg',
      'image/jpg',
      'image/png'
    ];

    if (
      !allowedTypes.includes(file.type)
    ) {

      this.validationErrors['shipmentImage'] =
        'Please upload JPG, JPEG or PNG image only.';

      input.value = '';

      this.cdr.markForCheck();

      return;
    }

    const maxSize =
      5 * 1024 * 1024;

    if (file.size > maxSize) {

      this.validationErrors['shipmentImage'] =
        'Image size should not exceed 5 MB.';

      input.value = '';

      this.cdr.markForCheck();

      return;
    }

    this.shipmentImage = file;

    this.shipmentImageName =
      file.name;

    const reader =
      new FileReader();

    reader.onload = () => {

      this.shipmentImagePreview =
        reader.result as string;

      this.validateField('shipmentImage');

      this.cdr.markForCheck();
    };

    reader.readAsDataURL(file);
  }

  removeShipmentImage(): void {

    this.shipmentImage = null;

    this.shipmentImagePreview = null;

    this.shipmentImageName = '';

    if (this.submitted) {
      this.validateField('shipmentImage');
    }

    this.cdr.markForCheck();
  }

  // =========================================================
  // BUILD API REQUEST
  // =========================================================

  private buildShipmentRequest(
    userId: number
  ): SaveShipmentRequest {

    const isAir =
      this.serviceType === 'Air Express' ||
      this.serviceType === 'Air';

    return {

      userId,

      orderId:
        this.getBookingOrderId(),

      serviceType:
        this.getServiceTypeCode(),


      noOfPackages:
        1,

      materialItem:
        this.materialType?.trim() || '',

      pickupDate:
        this.pickupDate,

      preferredTime:
        this.getPreferredTimeForApi(),

      remarks:
        this.remarks?.trim() || '',

      actualWeight:
        Number(this.actualWeight) || 0,

      volumetricCFT:
        Number(this.volumetricCft) || 0,

      chargeableWeight:
        Number(this.chargeableWeight) || 0,

      packageContentType:
        this.packageContentType?.trim() || '',

      packageDescription:
        this.packageDescription?.trim() || '',

      declaredValue:
        Number(this.declaredValue) || 0,

      surfaceLength:
        !isAir
          ? Number(this.length) || 0
          : 0,

      surfaceWidth:
        !isAir
          ? Number(this.breadth) || 0
          : 0,

      surfaceHeight:
        !isAir
          ? Number(this.height) || 0
          : 0,

      surfaceCFT:
        !isAir
          ? Number(this.volumetricCft) || 0
          : 0,

      airLength:
        isAir
          ? Number(this.length) || 0
          : 0,

      airWidth:
        isAir
          ? Number(this.breadth) || 0
          : 0,

      airHeight:
        isAir
          ? Number(this.height) || 0
          : 0,

      airCFT:
        isAir
          ? Number(this.volumetricCft) || 0
          : 0
    };
  }

  // =========================================================
  // SAVE + CONTINUE
  // =========================================================

 saveShipmentAndContinue(): void {

  console.log('========== CONTINUE CLICKED ==========');

  this.submitted = true;

  this.shipmentApiError = '';
  this.successMessage = '';

  console.log('Current form values:', {
    serviceType: this.serviceType,

    materialType: this.materialType,
    pickupDate: this.pickupDate,
    actualWeight: this.actualWeight,
    packageContentType: this.packageContentType,
    packageDescription: this.packageDescription,
    declaredValue: this.declaredValue,
    length: this.length,
    breadth: this.breadth,
    height: this.height,
    shipmentImage: this.shipmentImage
  });

  // Validate form
  const isValid = this.validateShipmentForm();

  console.log('Validation result:', isValid);
  console.log('Validation errors:', this.validationErrors);

  if (!isValid) {

    console.warn(
      'SHIPMENT VALIDATION FAILED - API WILL NOT BE CALLED'
    );

    this.shipmentApiError =
      'Please complete all required shipment details before continuing.';

    this.cdr.markForCheck();

    return;
  }

  console.log(
    'SHIPMENT VALIDATION PASSED - CONTINUING TO API'
  );

  const userId = this.getLoggedInUserId();
  const orderId = this.getBookingOrderId();

  console.log('User ID:', userId);
  console.log('Order ID:', orderId);

  if (!userId) {

    this.shipmentApiError =
      'User session not found. Please login again.';

    this.cdr.markForCheck();

    return;
  }

  if (!orderId) {

    this.shipmentApiError =
      'Booking order not found.';

    this.cdr.markForCheck();

    return;
  }

  // Calculate final weight
  this.calculateVolumetric();

  // Save locally
  this.saveShipmentDataLocally();

  // Build API request
  const request = this.buildShipmentRequest(userId);

  request.orderId = orderId;

  console.log('========== BEFORE SHIPMENT API ==========');
  console.log('UI serviceType:', this.serviceType);
  console.log(
    'Calculated service code:',
    this.getServiceTypeCode()
  );

  console.log('SHIPMENT REQUEST:', request);
  console.log(
    'Request serviceType:',
    request.serviceType
  );

  console.log('=========================================');

  this.isSaving = true;

  this.shipmentService.saveShipment(request).subscribe({

    next: (response: any) => {

      console.log(
        '========== SHIPMENT API RESPONSE =========='
      );

      console.log('Response:', response);

      this.isSaving = false;

      const isSuccess =
        response?.success === true ||
        response?.statusCode === '1' ||
        response?.statusCode === 1;

      if (!isSuccess) {

        this.shipmentApiError =
          response?.message ||
          'Unable to save shipment details.';

        this.cdr.markForCheck();

        return;
      }

      localStorage.setItem(
        'bookingOrderId',
        orderId
      );

      localStorage.setItem(
        'orderId',
        orderId
      );

      localStorage.setItem(
        'shipmentSaved',
        'true'
      );

      this.saveShipmentDataLocally();

      console.log(
        'Shipment saved successfully. Navigating to Freight.'
      );

      this.cdr.markForCheck();

      this.router.navigate([
        '/freight-calculator'
      ]);
    },

    error: (error: any) => {

      console.error(
        '========== SHIPMENT SAVE API ERROR =========='
      );

      console.error(error);

      this.isSaving = false;

      this.shipmentApiError =
        error?.error?.message ||
        error?.message ||
        'Unable to save shipment details.';

      this.cdr.markForCheck();
    }
  });
}
  // =========================================================
  // VALIDATE COMPLETE FORM
  // =========================================================

  private validateShipmentForm(): boolean {

    this.validationErrors = {};

    // -----------------------------------------------------
    // SERVICE TYPE
    // -----------------------------------------------------

    if (!this.serviceType?.trim()) {

      this.validationErrors['serviceType'] =
        'Please select a service type.';
    }

    // -----------------------------------------------------
    // SHIPMENT TYPE
    // -----------------------------------------------------



    // -----------------------------------------------------
    // PACKAGES
    // -----------------------------------------------------

    if (
      !this.numberOfPackages ||
      this.numberOfPackages < 1
    ) {

      this.validationErrors['numberOfPackages'] =
        'Number of packages must be at least 1.';
    }

    // -----------------------------------------------------
    // MATERIAL
    // -----------------------------------------------------

    if (!this.materialType?.trim()) {

      this.validationErrors['materialType'] =
        'Please select material type.';
    }

    // -----------------------------------------------------
    // PICKUP DATE
    // -----------------------------------------------------

    if (!this.pickupDate?.trim()) {

      this.validationErrors['pickupDate'] =
        'Please select pickup date.';
    }

    // -----------------------------------------------------
    // PICKUP DATE API ERROR
    // -----------------------------------------------------

    if (this.pickupDateError) {

      this.validationErrors['pickupDate'] =
        this.pickupDateError;
    }

    // -----------------------------------------------------
    // ACTUAL WEIGHT
    // -----------------------------------------------------

    const weight =
      Number(this.actualWeight) || 0;

    if (weight <= 0) {

      this.validationErrors['actualWeight'] =
        'Please enter actual weight.';
    }

    // -----------------------------------------------------
    // PACKAGE CONTENT
    // -----------------------------------------------------

    if (!this.packageContentType?.trim()) {

      this.validationErrors['packageContentType'] =
        'Please select package content type.';
    }

    // -----------------------------------------------------
    // PACKAGE DESCRIPTION
    // -----------------------------------------------------

    if (!this.packageDescription?.trim()) {

      this.validationErrors['packageDescription'] =
        'Please enter package description.';
    }

    // -----------------------------------------------------
    // DECLARED VALUE
    // -----------------------------------------------------

    const declaredValue =
      Number(this.declaredValue);

    if (
      this.declaredValue === null ||
      this.declaredValue === undefined ||
      Number.isNaN(declaredValue) ||
      declaredValue < 0
    ) {

      this.validationErrors['declaredValue'] =
        'Please enter declared value.';

    } else if (declaredValue > 49999) {

      this.validationErrors['declaredValue'] =
        'Declared value cannot be greater than ₹49,999.';
    }

    // =====================================================
    // WEIGHT > 2 KG
    // =====================================================

    if (weight > 2) {

      // ---------------------------------------------------
      // LENGTH
      // ---------------------------------------------------

      if (
        this.length === null ||
        this.length === undefined ||
        Number(this.length) <= 0
      ) {

        this.validationErrors['length'] =
          'Please enter length.';
      }

      // ---------------------------------------------------
      // BREADTH
      // ---------------------------------------------------

      if (
        this.breadth === null ||
        this.breadth === undefined ||
        Number(this.breadth) <= 0
      ) {

        this.validationErrors['breadth'] =
          'Please enter breadth.';
      }

      // ---------------------------------------------------
      // HEIGHT
      // ---------------------------------------------------

      if (
        this.height === null ||
        this.height === undefined ||
        Number(this.height) <= 0
      ) {

        this.validationErrors['height'] =
          'Please enter height.';
      }

      // ---------------------------------------------------
      // CFT
      // ---------------------------------------------------

      this.calculateVolumetric();

      if (
        !this.volumetricCft ||
        this.volumetricCft <= 0
      ) {

        this.validationErrors['volumetricCft'] =
          'Please enter valid dimensions to calculate CFT.';
      }

      // ---------------------------------------------------
      // CHARGEABLE WEIGHT
      // ---------------------------------------------------

      if (
        !this.chargeableWeight ||
        this.chargeableWeight <= 0
      ) {

        this.validationErrors['chargeableWeight'] =
          'Chargeable weight could not be calculated. Please check dimensions.';
      }

      // ---------------------------------------------------
      // IMAGE
      // ---------------------------------------------------

      if (
        !this.shipmentImage &&
        !this.shipmentImageName
      ) {

        this.validationErrors['shipmentImage'] =
          'Please upload shipment image for weight above 2 KG.';
      }
    }

    this.cdr.markForCheck();

    return (
      Object.keys(this.validationErrors)
        .length === 0
    );
  }

  // =========================================================
  // FIELD VALIDATION
  // =========================================================

  validateField(field: string): void {

    // Remove previous error
    delete this.validationErrors[field];

    switch (field) {

      case 'serviceType':

        if (!this.serviceType?.trim()) {

          this.validationErrors[field] =
            'Please select a service type.';
        }

        break;



      case 'numberOfPackages':

        if (
          !this.numberOfPackages ||
          this.numberOfPackages < 1
        ) {

          this.validationErrors[field] =
            'Number of packages must be at least 1.';
        }

        break;

      case 'materialType':

        if (!this.materialType?.trim()) {

          this.validationErrors[field] =
            'Please select material type.';
        }

        break;

      case 'pickupDate':

        if (!this.pickupDate?.trim()) {

          this.validationErrors[field] =
            'Please select pickup date.';
        }

        break;

      case 'actualWeight':

        if (
          !this.actualWeight ||
          Number(this.actualWeight) <= 0
        ) {

          this.validationErrors[field] =
            'Please enter actual weight.';
        }

        break;

      case 'packageContentType':

        if (!this.packageContentType?.trim()) {

          this.validationErrors[field] =
            'Please select package content type.';
        }

        break;

      case 'packageDescription':

        if (!this.packageDescription?.trim()) {

          this.validationErrors[field] =
            'Please enter package description.';
        }

        break;

      case 'declaredValue': {

        const value =
          Number(this.declaredValue);

        if (
          this.declaredValue === null ||
          this.declaredValue === undefined ||
          Number.isNaN(value)
        ) {

          this.validationErrors[field] =
            'Please enter declared value.';

        } else if (value < 0) {

          this.validationErrors[field] =
            'Declared value cannot be negative.';

        } else if (value > 49999) {

          this.validationErrors[field] =
            'Declared value cannot be greater than ₹49,999.';
        }

        break;
      }

      case 'length':

        if (
          Number(this.actualWeight) > 2 &&
          (
            this.length === null ||
            this.length === undefined ||
            Number(this.length) <= 0
          )
        ) {

          this.validationErrors[field] =
            'Please enter length.';
        }

        break;

      case 'breadth':

        if (
          Number(this.actualWeight) > 2 &&
          (
            this.breadth === null ||
            this.breadth === undefined ||
            Number(this.breadth) <= 0
          )
        ) {

          this.validationErrors[field] =
            'Please enter breadth.';
        }

        break;

      case 'height':

        if (
          Number(this.actualWeight) > 2 &&
          (
            this.height === null ||
            this.height === undefined ||
            Number(this.height) <= 0
          )
        ) {

          this.validationErrors[field] =
            'Please enter height.';
        }

        break;

      case 'shipmentImage':

        if (
          Number(this.actualWeight) > 2 &&
          !this.shipmentImage &&
          !this.shipmentImageName
        ) {

          this.validationErrors[field] =
            'Please upload shipment image for weight above 2 KG.';
        }

        break;
    }

    this.cdr.markForCheck();
  }

  // =========================================================
  // DECLARED VALUE
  // =========================================================

  onDeclaredValueChange(): void {

  let rawValue = String(this.declaredValue ?? '');

  // Keep digits only
  rawValue = rawValue.replace(/\D/g, '');

  // Empty input
  if (rawValue === '') {
    this.declaredValue = 0;

    delete this.validationErrors['declaredValue'];

    this.cdr.markForCheck();
    return;
  }

  const value = Number(rawValue);

  if (value > 49999) {

    this.declaredValue = 49999;

    this.validationErrors['declaredValue'] =
      'Declared value cannot be greater than ₹49,999.';

  } else {

    this.declaredValue = value;

    delete this.validationErrors['declaredValue'];
  }

  this.cdr.markForCheck();
}

  // =========================================================
  // PREFERRED TIME
  // =========================================================

  private getPreferredTimeForApi(): string {

    if (!this.preferredTime) {
      return '';
    }

    const value =
      this.preferredTime.trim();

    const match =
      value.match(
        /^(\d{1,2}):\d{2}\s*(AM|PM)\s*-\s*(\d{1,2}):\d{2}\s*(AM|PM)$/i
      );

    if (!match) {
      return value;
    }

    const startHour =
      match[1];

    const endHour =
      match[3];

    const endPeriod =
      match[4].toLowerCase();

    return `${startHour}-${endHour}${endPeriod}`;
  }

  // =========================================================
  // SERVICE CODE
  // =========================================================

  private getServiceTypeCode(): string {

    switch (this.serviceType) {

      case 'Surface':
      case 'Surface Express':
        return '21';

      case 'Air':
      case 'Air Express':
        return '23';

      case 'Rail':
      case 'Rail Express':
        return '24';

      default:
        return '';
    }
  }

  // =========================================================
  // BACK
  // =========================================================

  goBackFromPanGst(): void {

    const userId =
      localStorage.getItem('bookingUserId') ||
      localStorage.getItem('userId');

    const mobileNo =
      localStorage.getItem('mobileNo') ||
      localStorage.getItem('bookingMobileNo') ||
      localStorage.getItem('mobile');

    let panGstCompleted = false;

    if (mobileNo) {

      const mobileKey =
        `panGstCompleted_mobile_${mobileNo}`;

      panGstCompleted =
        localStorage.getItem(mobileKey) === 'true';
    }

    if (!panGstCompleted && userId) {

      const userKey =
        `panGstCompleted_${userId}`;

      panGstCompleted =
        localStorage.getItem(userKey) === 'true';
    }

    if (panGstCompleted) {

      this.router.navigate([
        '/address'
      ]);

      return;
    }

    this.router.navigate([
      '/pan-gst'
    ]);
  }

  // =========================================================
  // DATE RANGE
  // =========================================================

  private setPickupDateRange(): void {

    const today =
      new Date();

    this.today =
      this.formatDateForInput(today);

    const maxDate =
      new Date(today);

    maxDate.setDate(
      maxDate.getDate() + 7
    );

    this.maxPickupDate =
      this.formatDateForInput(maxDate);
  }

  private formatDateForInput(
    date: Date
  ): string {

    const year =
      date.getFullYear();

    const month =
      String(
        date.getMonth() + 1
      ).padStart(2, '0');

    const day =
      String(
        date.getDate()
      ).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  // =========================================================
  // GENERIC FIELD CHANGE
  // =========================================================

  onShipmentFieldChange(): void {

    if (this.submitted) {
      this.validateShipmentForm();
    }

    this.saveShipmentDataLocally();
  }
}
