import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanGstComponent } from './pan-gst.component';

describe('PanGstComponent', () => {
  let component: PanGstComponent;
  let fixture: ComponentFixture<PanGstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PanGstComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PanGstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
