import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { PanGstService } from '../../services/pan-gst.service';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';

@Component({
  selector: 'app-pan-gst',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, BookingShellComponent],
  templateUrl: './pan-gst.component.html',
  styleUrl: './pan-gst.component.css'
})
export class PanGstComponent {
  panNumber = '';
  gstNumber = '';
  customerType: 'Business' | 'Individual' = 'Business';
  isPanVerified = false;
  isPanVerifying = false;
  panVerificationMessage = '';
  panVerificationError = '';
  panVerificationData = '';
  isGstVerified = false;
  isGstVerifying = false;
  gstVerificationMessage = '';
  gstVerificationError = '';
  gstVerificationData = '';
  isVerified = false;
  isVerifying = false;
  verificationError = '';
  verificationMessage = '';

  private readonly PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
  private readonly GST_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;

  constructor(private readonly panGstService: PanGstService, private readonly router: Router) { this.loadSavedVerification(); }

  get isPanValid(): boolean { return this.PAN_REGEX.test(this.panNumber.trim().toUpperCase()); }
  get isGstValid(): boolean { return this.GST_REGEX.test(this.gstNumber.trim().toUpperCase()); }

  onPanChange(): void { this.panNumber = this.normalize(this.panNumber); this.resetPanVerification(); this.resetCombinedVerification(); }
  onGstChange(): void { this.gstNumber = this.normalize(this.gstNumber); this.resetGstVerification(); this.resetCombinedVerification(); }

  onCustomerTypeChange(): void {
    this.resetGstVerification(); this.resetCombinedVerification(); this.gstNumber = '';
    if (this.customerType === 'Individual') {
      this.gstVerificationMessage = 'GST verification is not required for Individual customer.';
    }
  }


  verifyPan(): void {
    this.resetPanVerification();
    this.panNumber = this.normalize(this.panNumber);
    if (!this.panNumber) {
      this.panVerificationError =
        'Please enter your PAN number.';
      return;
    }
    if (!this.isPanValid) {
      this.panVerificationError =
        'Please enter a valid PAN number.';
      return;
    }
    this.isPanVerifying = true;
    this.panGstService.verifyPan(this.panNumber).subscribe({
      next: (response) => {
        this.isPanVerifying = false;
        if (response?.success === true) { this.isPanVerified = true; this.panVerificationMessage = response.message || 'PAN verified successfully.'; this.panVerificationData = response.data || response.message || ''; }
        else {
          this.isPanVerified = false;
          this.panVerificationError =
            response?.message ||
            'PAN verification failed.';
        }
        this.updateCombinedVerification();
      },
      error: (error) => {
        this.isPanVerifying = false;
        this.isPanVerified = false;
        console.error(
          'PAN Verification Error:',
          error
        );
        this.panVerificationError =
          this.getApiErrorMessage(
            error,
            'Unable to verify PAN. Please try again.'
          );
        this.updateCombinedVerification();
      }
    });
  }

  verifyGst(): void {
    this.resetGstVerification();
    this.gstNumber = this.normalize(
      this.gstNumber
    );
    if (this.customerType === 'Individual') {
      this.isGstVerified = false;
      this.gstVerificationMessage =
        'GST verification is not required for Individual customer.';
      this.updateCombinedVerification();
      return;
    }
    if (!this.gstNumber) {
      this.gstVerificationError =
        'Please enter your GST number.';
      return;
    }
    if (!this.isGstValid) {this.gstVerificationError ='Please enter a valid GST number.';
      return;
    }
    this.isGstVerifying = true;
    this.panGstService
      .verifyGst(this.gstNumber)
      .subscribe({
        next: (response) => {
          this.isGstVerifying = false;
          if (response?.success === true) {
            this.isGstVerified = true;
            this.gstVerificationMessage =
              'GST verified successfully.';
            this.gstVerificationData =
              response.data ||
              response.message ||
              '';
          } else {
            this.isGstVerified = false;
            this.gstVerificationError =
              response?.message ||
              'GST verification failed.';
          }

          this.updateCombinedVerification();
        },
        error: (error) => {
          this.isGstVerifying = false;
          this.isGstVerified = false;
          console.error(
            'GST Verification Error:',
            error
          );
          this.gstVerificationError =
            this.getApiErrorMessage(
              error,
              'Unable to verify GST. Please try again.'
            );
          this.updateCombinedVerification();
        }
      });
  }

  verifyPanGst(): void {

    this.resetCombinedVerification();
    this.resetPanVerification();
    this.resetGstVerification();
    this.panNumber = this.normalize(this.panNumber);
    this.gstNumber = this.normalize(this.gstNumber);
    // PAN is mandatory
    if (!this.panNumber) {
      this.verificationError =
        'Please enter your PAN number.';
      return;
    }
    if (!this.isPanValid) {
      this.verificationError =
        'Please enter a valid PAN number.';
      return;
    }
    if (
      this.gstNumber &&
      !this.isGstValid
    ) {
      this.verificationError =
        'Please enter a valid GST number.';
      return;
    }
    this.isVerifying = true;
    this.isPanVerifying = true;
    this.panGstService.verifyPan(this.panNumber).subscribe({
      next: (panResponse) => {
        this.isPanVerifying = false;
        if (
          !panResponse ||
          panResponse.success !== true
        ) {
          this.isVerifying = false;
          this.isPanVerified = false;
          this.isVerified = false;
          this.panVerificationError =
            panResponse?.message ||
            'PAN verification failed.';
          this.verificationError =
            this.panVerificationError;
          return;
        }

        // PAN verified
        this.isPanVerified = true;
        this.panVerificationMessage =
          panResponse.message ||
          'PAN verified successfully.';
        this.panVerificationData =
          panResponse.data ||
          panResponse.message ||
          '';
        if (!this.gstNumber) {
          this.isVerifying = false;
          this.isVerified = true;
          this.verificationMessage =
            'PAN verified successfully. GST verification was skipped.';
          this.verificationError = '';
          this.saveVerificationData();
          return;
        }
        this.verifyGstAfterPan();
      },
      error: (error) => {
        this.isPanVerifying = false;
        this.isVerifying = false;
        this.isPanVerified = false;
        this.isVerified = false;
        console.error(
          'PAN Verification Error:',
          error
        );
        this.panVerificationError =
          this.getApiErrorMessage(
            error,
            'Unable to verify PAN. Please try again.'
          );
        this.verificationError =
          this.panVerificationError;
      }
    });
  }
  private verifyGstAfterPan(): void {
    this.isGstVerifying = true;
    this.panGstService
      .verifyGst(this.gstNumber)
      .subscribe({
        next: (gstResponse) => {
          this.isGstVerifying = false;
          this.isVerifying = false;

          if (
            !gstResponse ||
            gstResponse.success !== true
          ) {
            this.isGstVerified = false;
            this.isVerified = false;
            this.gstVerificationError =
              gstResponse?.message ||
              'GST verification failed.';
            this.verificationError =
              this.gstVerificationError;
            return;
          }
          this.isGstVerified = true;
          this.gstVerificationMessage ='GST verified successfully.';
          this.gstVerificationData = gstResponse.data ||gstResponse.message ||'';
          this.isVerified =this.isPanVerified && this.isGstVerified;
          if (this.isVerified) {this.verificationMessage = 'PAN & GST verified successfully.';
            this.verificationError = '';this.saveVerificationData();
          }
        },

        error: (error) => {
          this.isGstVerifying = false;
          this.isVerifying = false;
          this.isGstVerified = false;
          this.isVerified = false;
          console.error(
            'GST Verification Error:',
            error
          );
          this.gstVerificationError =
            this.getApiErrorMessage(
              error,
              'Unable to verify GST. Please try again.'
            );
          this.verificationError =
            this.gstVerificationError;
        }
      });
  }

  private updateCombinedVerification(): void {
    // PAN is always mandatory
    if (!this.isPanVerified) {
      this.isVerified = false;
      return;
    }
    if (!this.gstNumber) {
      this.isVerified = true;
      return;
    }
    this.isVerified =
      this.isPanVerified &&
      this.isGstVerified;
  }


  get canContinue(): boolean {
    if (!this.isPanVerified) {
      return false;}
    if (this.gstNumber &&!this.isGstVerified) {
      return false;}
    return true;
  }



continue(): void { if (!this.canContinue) { return;}
  this.saveVerificationData();
  this.markPanGstCompleted();
  this.router.navigate([
    '/shipment-package'
  ]);
}

private markPanGstCompleted(): void {
  const userId =localStorage.getItem('bookingUserId') ||localStorage.getItem('userId');
  const mobileNo =localStorage.getItem('mobileNo') ||localStorage.getItem('bookingMobileNo') ||localStorage.getItem('mobile');
  if (userId) {
    const userKey = `panGstCompleted_${userId}`;
    localStorage.setItem(userKey, 'true');
  }
  if (mobileNo) {
    const mobileKey =`panGstCompleted_mobile_${mobileNo}`;
    localStorage.setItem(mobileKey, 'true');
  }
  localStorage.setItem(
    'panGstVerified',
    'true'
  );
}


  private saveVerificationData(): void {
    localStorage.setItem( 'customerType',this.customerType);
    localStorage.setItem('panNumber',this.panNumber);
    localStorage.setItem('panVerified',String(this.isPanVerified));
    if (this.panVerificationData) {localStorage.setItem( 'panVerificationData', this.panVerificationData);}
    if (this.customerType === 'Business') { localStorage.setItem( 'gstNumber', this.gstNumber);localStorage.setItem('gstVerified',String(this.isGstVerified));
    if (this.gstVerificationData) { localStorage.setItem( 'gstVerificationData',this.gstVerificationData);}}
    else {localStorage.removeItem( 'gstNumber');
         localStorage.removeItem('gstVerified');
         localStorage.removeItem('gstVerificationData');}
         localStorage.setItem('panGstVerified',
         String(this.isVerified)
    );
  }


  private loadSavedVerification(): void {
    try {
      const savedCustomerType =localStorage.getItem('customerType');
      if ( savedCustomerType === 'Business' ||savedCustomerType === 'Individual') {
        this.customerType = savedCustomerType;}
      const savedPan = localStorage.getItem('panNumber');
      const savedPanVerified =localStorage.getItem('panVerified');
      const savedPanData = localStorage.getItem('panVerificationData');
      if (savedPan) {this.panNumber =this.normalize(savedPan);}
      if ( savedPanVerified === 'true' && this.isPanValid)
      { this.isPanVerified = true;
        this.panVerificationMessage ='PAN already verified.';
        this.panVerificationData = savedPanData || '';
      }
      if (
        this.customerType === 'Business') {
        const savedGst = localStorage.getItem('gstNumber');
        const savedGstVerified =localStorage.getItem('gstVerified');
        const savedGstData = localStorage.getItem('gstVerificationData');
        if (savedGst) {this.gstNumber =  this.normalize(savedGst);}
        if ( savedGstVerified === 'true' && this.isGstValid) {
          this.isGstVerified = true;
          this.gstVerificationMessage ='GST already verified.';
          this.gstVerificationData = savedGstData || '';
        }
      }
      this.updateCombinedVerification();
      if (this.isVerified) {
        this.verificationMessage =
          this.customerType === 'Business'
            ? 'PAN & GST already verified.'
            : 'PAN already verified.';
      }
    } catch (error) {
      console.error(
        'Unable to load saved PAN/GST verification:',
        error
      );
    }
  }

  private normalize(value: string): string {
    return (value || '').trim() .toUpperCase() .replace(/\s/g, '');
  }

  private resetPanVerification(): void {
    this.isPanVerified = false;
    this.isPanVerifying = false;
    this.panVerificationMessage = '';
    this.panVerificationError = '';
    this.panVerificationData = '';
  }

  private resetGstVerification(): void {
    this.isGstVerified = false;
    this.isGstVerifying = false;
    this.gstVerificationMessage = '';
    this.gstVerificationError = '';
    this.gstVerificationData = '';
  }



  private resetCombinedVerification(): void {
    this.isVerified = false;
    this.isVerifying = false;
    this.verificationError = '';
    this.verificationMessage = '';
  }


  private getApiErrorMessage(error: any,fallback: string): string {
    return ( error?.error?.message ||error?.error?.title ||error?.message ||fallback);
  }
}
