
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-payment-failure',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-failure.component.html',
  styleUrl: './payment-failure.component.css'
})
export class PaymentFailureComponent implements OnInit {

  txnId = '';
  amount = '';
  error = '';
  errorMessage = '';
  mihpayId = '';
  orderId = localStorage.getItem('bookingOrderId') || '';

  constructor(private readonly route: ActivatedRoute,private readonly router: Router) {}

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.txnId = params.get('txnid') ||params.get('txnId') || localStorage.getItem('bookingOrderId') || '';
      this.amount =params.get('amount') || '';
      this.error = params.get('error') || '';
      this.errorMessage = params.get('error_Message') ||params.get('errorMessage') || '';
      this.mihpayId = params.get('mihpayid') ||
        '';
    });
  }

  retryPayment(): void {
    this.router.navigate(['/freight-calculator']);
  }

  goToBooking(): void {
    this.router.navigate(['/service-check']);
  }

}

