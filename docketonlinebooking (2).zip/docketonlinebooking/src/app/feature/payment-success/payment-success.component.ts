import {ChangeDetectorRef,Component,OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { PaymentService } from '../../services/payment.service';
import JsBarcode from 'jsbarcode';
import {PaymentSuccessWebhookRequest,PaymentSuccessWebhookResponse} from '../models/onlinebooking.model';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [CommonModule,BookingShellComponent],
  templateUrl: './payment-success.component.html',
  styleUrls: ['./payment-success.component.css']
})
export class PaymentSuccessComponent implements OnInit {


  txnId = '';
  amount = '';
  mihpayId = '';
  mode = '';
  bankRefNum = '';
  referenceId = '';
  orderId = '';
  userId = '';
  serviceType = '';
  pickupDate = '';
  pickupCity = '';
  deliveryCity = '';
  pickupPincode = '';
  deliveryPincode = '';
  customerName = '';
  mobileNumber = '';
  custcode = '';
  referenceGenerated = false;
  paymentSaved = false;
  custCodeCreated = false;
  customerInformationSaved = false;
  cmfPickupSaved = false;
  whatsappSent = false;
  webhookCalled = false;
  webhookSuccess = false;
  webhookLoading = false;
  webhookError = false;
  loading = true;
  errorMessage = '';


  private paymentProcessStarted = false;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly paymentService: PaymentService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  // =========================================================
  // ON INIT
  // =========================================================

  ngOnInit(): void {

    console.log('==============================================');
    console.log('PAYMENT SUCCESS PAGE INITIALIZED');
    console.log('==============================================');

    this.route.queryParams.subscribe(params => {

      console.log('Payment success query params:', params);

      this.loadPaymentDetails(params);

      this.loadBookingDetails();

      /*
       * Start the complete payment-success process
       * only once.
       */
      if (!this.paymentProcessStarted) {

        this.paymentProcessStarted = true;

        this.createReferenceId();
      }

    });
  }

  // =========================================================
  // LOAD PAYMENT DETAILS
  // =========================================================

  private loadPaymentDetails(params: any): void {

  console.log('Loading payment details...');
  console.log('Complete PayU params:', params);

  this.txnId =
    params['txnid'] ||
    params['txnId'] ||
    params['mihpayid'] ||
    this.getStorageString('paymentTxnId') ||
    this.getStorageString('txnId') ||
    '';

  this.amount =
    params['amount'] ||
    this.getStorageString('paymentAmount') ||
    this.getStorageString('amount') ||
    '';

  this.mihpayId =
    params['mihpayid'] ||
    params['mihpayId'] ||
    params['mihpay_id'] ||
    this.getStorageString('mihpayId') ||
    '';

  this.mode =
    params['mode'] ||
    params['PG_TYPE'] ||
    params['paymentMode'] ||
    this.getStorageString('paymentMode') ||
    '';

  // =======================================================
  // BANK REFERENCE NUMBER
  // =======================================================

  const bankReference =
    params['bank_ref_num'] ||
    params['bank_ref_no'] ||
    params['bankReferenceNumber'] ||
    params['bank_ref_number'] ||
    params['bank_ref'] ||
    params['bankReference'] ||
    params['bank_ref_num'] ||
    this.getStorageString('bankReferenceNumber') ||
    this.getStorageString('bankRefNum') ||
    '';

  this.bankRefNum =
    String(bankReference || '').trim();

  // Persist it immediately
  if (this.bankRefNum) {

    localStorage.setItem(
      'bankReferenceNumber',
      this.bankRefNum
    );

    sessionStorage.setItem(
      'bankReferenceNumber',
      this.bankRefNum
    );

    localStorage.setItem(
      'bankRefNum',
      this.bankRefNum
    );

    sessionStorage.setItem(
      'bankRefNum',
      this.bankRefNum
    );
  }

  // =======================================================
  // ORDER ID
  // =======================================================

  this.orderId =
    params['orderId'] ||
    params['order_id'] ||
    this.getStorageString('bookingOrderId') ||
    this.getStorageString('orderId') ||
    '';

  // =======================================================
  // USER ID
  // =======================================================

  this.userId =
    params['userId'] ||
    params['user_id'] ||
    this.getStorageString('bookingUserId') ||
    this.getStorageString('userId') ||
    '';

  // =======================================================
  // REFERENCE
  // =======================================================

  this.referenceId =
    params['referenceId'] ||
    params['bookingReferenceId'] ||
    this.getStorageString('bookingReferenceId') ||
    this.getStorageString('referenceId') ||
    '';

  console.log('Loaded payment details:', {
    txnId: this.txnId,
    amount: this.amount,
    mihpayId: this.mihpayId,
    mode: this.mode,
    bankRefNum: this.bankRefNum,
    orderId: this.orderId,
    userId: this.userId,
    referenceId: this.referenceId
  });

  this.cdr.markForCheck();
}

  // =========================================================
  // LOAD BOOKING DETAILS
  // =========================================================

  private loadBookingDetails(): void {

  console.log('==============================================');
  console.log('LOADING BOOKING DETAILS');
  console.log('==============================================');

  const userId =
    this.getStorageString('bookingUserId') ||
    this.getStorageString('userId');

  const sessionId =
    this.getStorageString(
      'tci_active_booking_session'
    );

  console.log('userId:', userId);
  console.log('sessionId:', sessionId);

  // =======================================================
  // USER DATA
  // =======================================================

  const userData =
    this.getStoredJson([
      'bookingUser',
      'userData',
      'loggedInUser',
      'customerData',
      'user'
    ]);

  console.log('User data from storage:', userData);

  if (userData) {

    this.customerName =
      userData['customerName'] ||
      userData['customer_name'] ||
      userData['fullName'] ||
      userData['full_name'] ||
      userData['name'] ||
      userData['contactPerson'] ||
      userData['contactPersonName'] ||
      userData['contactName'] ||
      userData['firstName'] ||
      '';

    this.mobileNumber =
      userData['mobileNo'] ||
      userData['mobileNO'] ||
      userData['mobile'] ||
      userData['phone'] ||
      userData['phoneNumber'] ||
      '';
  }

  // =======================================================
  // MOBILE FALLBACK
  // =======================================================

  if (!this.mobileNumber) {

    this.mobileNumber =
      this.getStorageString('mobileNo') ||
      this.getStorageString('bookingMobile') ||
      '';

  }

  // =======================================================
  // PICKUP ADDRESS
  // =======================================================

  const pickupKeys: string[] = [];

  if (userId && sessionId) {

    pickupKeys.push(
      `tci_booking_pickup_address_${userId}_${sessionId}`
    );

  }

  pickupKeys.push(
    'tci_booking_pickup_address',
    'pickupAddress',
    'tci_booking_address'
  );

  const pickupAddress =
    this.getStoredJson(pickupKeys);

  console.log(
    'Pickup address:',
    pickupAddress
  );

  if (pickupAddress) {

    this.pickupCity =
      pickupAddress['city'] ||
      pickupAddress['pickupCity'] ||
      pickupAddress['location'] ||
      pickupAddress['pickupLocation'] ||
      '';

    this.pickupPincode =
      pickupAddress['pincode'] ||
      pickupAddress['pinCode'] ||
      pickupAddress['pickupPincode'] ||
      pickupAddress['pickupPinCode'] ||
      '';

    // -----------------------------------------------------
    // CUSTOMER NAME FROM PICKUP ADDRESS
    // -----------------------------------------------------

    if (!this.customerName) {

      this.customerName =
        pickupAddress['customerName'] ||
        pickupAddress['customer_name'] ||
        pickupAddress['fullName'] ||
        pickupAddress['full_name'] ||
        pickupAddress['name'] ||
        pickupAddress['contactPerson'] ||
        pickupAddress['contactPersonName'] ||
        pickupAddress['contactName'] ||
        pickupAddress['consignorName'] ||
        pickupAddress['consignor_name'] ||
        '';

    }

    // -----------------------------------------------------
    // MOBILE FROM PICKUP ADDRESS
    // -----------------------------------------------------

    if (!this.mobileNumber) {

      this.mobileNumber =
        pickupAddress['mobileNo'] ||
        pickupAddress['mobileNO'] ||
        pickupAddress['mobile'] ||
        pickupAddress['phone'] ||
        pickupAddress['phoneNumber'] ||
        pickupAddress['contactNumber'] ||
        '';

    }

  }

  // =======================================================
  // DELIVERY ADDRESS
  // =======================================================

  const deliveryKeys: string[] = [];

  if (userId && sessionId) {

    deliveryKeys.push(
      `tci_booking_delivery_address_${userId}_${sessionId}`
    );

  }

  deliveryKeys.push(
    'tci_booking_delivery_address',
    'deliveryAddress'
  );

  const deliveryAddress =
    this.getStoredJson(deliveryKeys);

  console.log(
    'Delivery address:',
    deliveryAddress
  );

  if (deliveryAddress) {

    this.deliveryCity =
      deliveryAddress['city'] ||
      deliveryAddress['deliveryCity'] ||
      deliveryAddress['location'] ||
      deliveryAddress['deliveryLocation'] ||
      '';

    this.deliveryPincode =
      deliveryAddress['pincode'] ||
      deliveryAddress['pinCode'] ||
      deliveryAddress['deliveryPincode'] ||
      deliveryAddress['deliveryPinCode'] ||
      '';

  }

  // =======================================================
  // SHIPMENT DATA
  // =======================================================

  const shipmentKeys: string[] = [];

  if (userId && sessionId) {

    shipmentKeys.push(
      `tci_booking_shipment_data_${userId}_${sessionId}`
    );

  }

  shipmentKeys.push(
    'tci_booking_shipment_data',
    'shipmentData'
  );

  const shipmentData =
    this.getStoredJson(shipmentKeys);

  console.log(
    'Shipment data:',
    shipmentData
  );

  if (shipmentData) {

    this.serviceType =
      shipmentData['serviceType'] ||
      shipmentData['shipmentType'] ||
      shipmentData['service'] ||
      '';

    this.pickupDate =
      shipmentData['pickupDate'] ||
      shipmentData['bookingDate'] ||
      '';

    // -----------------------------------------------------
    // CUSTOMER NAME FROM SHIPMENT DATA
    // -----------------------------------------------------

    if (!this.customerName) {

      this.customerName =
        shipmentData['customerName'] ||
        shipmentData['customer_name'] ||
        shipmentData['consignorName'] ||
        shipmentData['consignor_name'] ||
        '';

    }

  }

  // =======================================================
  // GENERIC FALLBACKS
  // =======================================================

  if (!this.customerName) {

    this.customerName =
      this.getStorageString('customerName') ||
      this.getStorageString('customer_name') ||
      this.getStorageString('fullName') ||
      this.getStorageString('full_name') ||
      '';

  }

  if (!this.serviceType) {

    this.serviceType =
      this.getStorageString('serviceType') ||
      '';

  }

  if (!this.pickupDate) {

    this.pickupDate =
      this.getStorageString('pickupDate') ||
      '';

  }

  console.log('==============================================');
  console.log('FINAL BOOKING DETAILS');
  console.log('==============================================');

  console.log({
    customerName: this.customerName,
    mobileNumber: this.mobileNumber,
    pickupCity: this.pickupCity,
    deliveryCity: this.deliveryCity,
    pickupPincode: this.pickupPincode,
    deliveryPincode: this.deliveryPincode,
    serviceType: this.serviceType,
    pickupDate: this.pickupDate,
    bankRefNum: this.bankRefNum
  });

  this.cdr.markForCheck();
}
  // =========================================================
  // STEP 1
  // GENERATE REFERENCE NUMBER
  // =========================================================

  private createReferenceId(): void {

    if (!this.orderId) {

      console.error(
        'Cannot generate reference number: Order ID is missing.'
      );

      this.errorMessage =
        'Order ID is missing. Unable to generate booking reference.';

      this.loading = false;

      this.cdr.markForCheck();

      return;
    }

    // -------------------------------------------------------
    // DO NOT GENERATE AGAIN
    // -------------------------------------------------------

    const storedReference =
      this.getStorageString('bookingReferenceId');

    if (storedReference) {

      console.log(
        'Reference already exists:',
        storedReference
      );

      this.referenceId = storedReference;
      this.referenceGenerated = true;

      this.savePaymentSuccess();

      return;
    }

    console.log(
      'Calling generate-reference API...',
      {
        orderId: this.orderId
      }
    );

    this.paymentService
      .generateReference(this.orderId)
      .subscribe({

        next: response => {

          console.log(
            'Generate Reference Response:',
            response
          );

          if (
            response?.success !== true ||
            !response?.referenceId
          ) {

            console.error(
              'Reference generation failed:',
              response
            );

            this.errorMessage =
              response?.message ||
              'Unable to generate booking reference.';

            this.loading = false;

            this.cdr.markForCheck();

            return;
          }

          this.referenceId =
            String(response.referenceId).trim();

          this.referenceGenerated = true;

          // -------------------------------------------------
          // SAVE REFERENCE
          // -------------------------------------------------

          localStorage.setItem(
            'bookingReferenceId',
            this.referenceId
          );

          sessionStorage.setItem(
            'bookingReferenceId',
            this.referenceId
          );

          console.log(
            'Reference generated successfully:',
            this.referenceId
          );

          // -------------------------------------------------
          // BARCODE
          // -------------------------------------------------

          this.generateBarcode();

          // -------------------------------------------------
          // NEXT STEP
          // -------------------------------------------------

          this.savePaymentSuccess();

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'Generate Reference API failed:',
            error
          );

          this.errorMessage =
            'Unable to generate booking reference.';

          this.loading = false;

          this.cdr.markForCheck();
        }

      });
  }

  // =========================================================
  // STEP 2
  // SAVE PAYMENT SUCCESS
  // =========================================================

  private savePaymentSuccess(): void {

    if (this.paymentSaved) {

      console.log(
        'Payment already saved.'
      );

      this.createCustCode();

      return;
    }

    const numericUserId =
      Number(this.userId);

    const numericAmount =
      Number(this.amount);

    if (!numericUserId || numericUserId <= 0) {

      console.error(
        'Payment save failed: Invalid User ID.',
        this.userId
      );

      return;
    }

    if (!this.orderId) {

      console.error(
        'Payment save failed: Order ID is missing.'
      );

      return;
    }

    if (!this.referenceId) {

      console.error(
        'Payment save failed: Reference ID is missing.'
      );

      return;
    }

    const payload = {

      userId: numericUserId,

      orderId:
        String(this.orderId).trim(),

      bookingRefId:
        String(this.referenceId).trim(),

      transactionId:
        String(this.txnId || '').trim(),

      amountPaid:
        Number.isFinite(numericAmount)
          ? numericAmount
          : 0,

      paymentId:
        String(this.mihpayId || '').trim(),

      paymentMode:
        String(this.mode || 'PayU').trim(),

      bankRefNum:
        String(this.bankRefNum || '').trim()

    };

    console.log(
      'Calling save-payment-success API:',
      payload
    );

    this.paymentService
      .savePaymentSuccess(payload)
      .subscribe({

        next: response => {

          console.log(
            'Save Payment Response:',
            response
          );


          const success =
            response?.success === true ||
            response?.status === true ||
            response?.Status === true;

          if (!success) {

            console.error(
              'Save Payment API unsuccessful:',
              response
            );

            return;
          }

          this.paymentSaved = true;

          console.log(
            'Payment saved successfully.'
          );

          // -------------------------------------------------
          // NEXT STEP
          // -------------------------------------------------

          this.createCustCode();

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'Save Payment API failed:',
            error
          );

        }

      });
  }

  // =========================================================
  // STEP 3
  // CREATE CUSTOMER CODE
  // =========================================================

  private createCustCode(): void {

    if (this.custCodeCreated) {

      console.log(
        'CustCode already created.'
      );

      this.saveCustomerInformation(
        Number(this.custcode)
      );

      return;
    }

    if (!this.orderId) {

      console.error(
        'CustCode failed: Order ID is missing.'
      );

      return;
    }

    console.log(
      'Calling CMFPICKUP/CustCode API:',
      {
        orderId: this.orderId
      }
    );

    this.paymentService
      .createCustCode(this.orderId)
      .subscribe({

        next: response => {

          console.log(
            'CustCode Response:',
            response
          );

          /*
           * Expected response example:
           *
           * {
           *   status: 1,
           *   data: {
           *     custCode: 123,
           *     groupCustCode: 456
           *   }
           * }
           */

          const status =
            response?.status === 1 ||
            response?.status === true ||
            response?.Status === 1 ||
            response?.Status === true;

          const data =
            response?.data ||
            response?.Data ||
            {};

          const custCode =
            Number(
              data?.custCode ??
              data?.CustCode ??
              response?.custCode ??
              response?.CustCode
            );

          const groupCustCode =
            Number(
              data?.groupCustCode ??
              data?.GroupCustCode ??
              response?.groupCustCode ??
              response?.GroupCustCode
            );

          if (!status) {

            console.error(
              'CustCode API unsuccessful:',
              response
            );

            return;
          }

          if (!this.isValidPositiveNumber(custCode)) {

            console.error(
              'Invalid CustCode received:',
              custCode
            );

            return;
          }

          if (!this.isValidPositiveNumber(groupCustCode)) {

            console.error(
              'Invalid GroupCustCode received:',
              groupCustCode
            );

            return;
          }

          this.custcode =
            String(custCode);

          this.custCodeCreated = true;

          localStorage.setItem(
            'custcode',
            this.custcode
          );

          sessionStorage.setItem(
            'custcode',
            this.custcode
          );

          console.log(
            'CustCode created successfully:',
            {
              custCode,
              groupCustCode
            }
          );

          // -------------------------------------------------
          // NEXT STEP
          // -------------------------------------------------

          this.saveCustomerInformation(
            custCode,
            groupCustCode
          );

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'CustCode API failed:',
            error
          );

        }

      });
  }

  // =========================================================
  // STEP 4
  // SAVE CUSTOMER INFORMATION
  // =========================================================

  private saveCustomerInformation(
    custCode: number,
    groupCustCode?: number
  ): void {

    if (this.customerInformationSaved) {

      console.log(
        'Customer Information already saved.'
      );

      this.processCmfPickup(custCode);

      return;
    }

    if (!this.orderId) {

      console.error(
        'Customer Information failed: Order ID missing.'
      );

      return;
    }

    if (!this.isValidPositiveNumber(custCode)) {

      console.error(
        'Customer Information failed: Invalid CustCode.',
        custCode
      );

      return;
    }

    const storedGroupCustCode =
      groupCustCode ??
      Number(
        this.getStorageString('groupCustCode')
      );

    if (
      !this.isValidPositiveNumber(
        storedGroupCustCode
      )
    ) {

      console.error(
        'Customer Information failed: Invalid GroupCustCode.',
        storedGroupCustCode
      );

      return;
    }

    console.log(
      'Calling CMFPICKUP/CustomerInformation API:',
      {
        orderId: this.orderId,
        groupCustCode: storedGroupCustCode,
        custCode
      }
    );

    this.paymentService
      .saveCustomerInformation(
        this.orderId,
        storedGroupCustCode,
        custCode
      )
      .subscribe({

        next: response => {

          console.log(
            'CustomerInformation Response:',
            response
          );

          const success =
            response?.status === true ||
            response?.status === 1 ||
            response?.Status === true ||
            response?.Status === 1 ||
            response?.success === true;

          if (!success) {

            console.error(
              'CustomerInformation API unsuccessful:',
              response
            );

            return;
          }

          this.customerInformationSaved = true;

          console.log(
            'Customer Information saved successfully.'
          );

          // -------------------------------------------------
          // NEXT STEP
          // -------------------------------------------------

          this.processCmfPickup(
            custCode
          );

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'CustomerInformation API failed:',
            error
          );

        }

      });
  }

  // =========================================================
  // STEP 5
  // SAVE CMF PICKUP
  // =========================================================

  private processCmfPickup(
    custCode: number
  ): void {

    if (this.cmfPickupSaved) {

      console.log(
        'CMF Pickup already saved.'
      );

      /*
       * If somehow CMF was already saved but WhatsApp
       * was not sent, continue from WhatsApp.
       */
      if (!this.whatsappSent) {
        this.sendBookingWhatsApp();
      }

      return;
    }

    if (!this.orderId) {

      console.error(
        'CMF Pickup failed: Order ID is missing.'
      );

      return;
    }

    if (
      !this.isValidPositiveNumber(
        custCode
      )
    ) {

      console.error(
        'CMF Pickup failed: Invalid CustCode.',
        custCode
      );

      return;
    }

    const orderId =
      String(this.orderId).trim();

    const custcode =
      String(custCode).trim();

    console.log(
      'Calling CMFPICKUP/pickuprqst_save API:',
      {
        orderId,
        custcode
      }
    );

    this.paymentService
      .saveCmfPickup(
        orderId,
        custcode
      )
      .subscribe({

        next: response => {

          console.log(
            'CMFPICKUP/pickuprqst_save Response:',
            response
          );

          const success =
            response?.success === true ||
            response?.status === true ||
            response?.status === 1 ||
            response?.Status === true ||
            response?.Status === 1;

          if (!success) {

            console.error(
              'CMFPICKUP/pickuprqst_save failed:',
              response
            );

            return;
          }

          this.cmfPickupSaved = true;

          console.log(
            '=============================================='
          );

          console.log(
            'CMF PICKUP SAVED SUCCESSFULLY'
          );

          console.log(
            '=============================================='
          );

          /*
           * IMPORTANT:
           *
           * WhatsApp MUST be called after CMF Pickup.
           *
           * DO NOT call webhook directly here.
           */

          this.sendBookingWhatsApp();

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'CMFPICKUP/pickuprqst_save API failed:',
            error
          );

        }

      });
  }

  // =========================================================
  // STEP 6
  // SEND WHATSAPP
  // =========================================================

  private sendBookingWhatsApp(): void {

    if (this.whatsappSent) {

      console.log(
        'WhatsApp already sent.'
      );

      /*
       * Continue to webhook if needed.
       */
      if (!this.webhookCalled) {
        this.callPaymentSuccessWebhook();
      }

      return;
    }

    if (!this.referenceId) {

      console.error(
        'WhatsApp not sent: Reference ID is missing.'
      );

      /*
       * Do not block webhook forever.
       */
      this.callPaymentSuccessWebhook();

      return;
    }

    const phone =
      this.getLoggedInMobile();

    if (!phone) {

      console.error(
        'WhatsApp not sent: Mobile number is missing.'
      );

      /*
       * WhatsApp is a notification.
       * It should not block payment webhook.
       */
      this.callPaymentSuccessWebhook();

      return;
    }

    console.log(
      '=============================================='
    );

    console.log(
      'CALLING SEND WHATSAPP API'
    );

    console.log(
      '=============================================='
    );

    console.log(
      'WhatsApp Request:',
      {
        refNo: this.referenceId,
        phone
      }
    );

    this.paymentService
      .sendBookingWhatsApp(
        this.referenceId,
        phone
      )
      .subscribe({

        next: response => {

          console.log(
            'Send WhatsApp Response:',
            response
          );

          const success =
            response?.success === true;

          if (!success) {

            console.warn(
              'WhatsApp API returned unsuccessful response:',
              response
            );

            /*
             * IMPORTANT:
             *
             * Even if WhatsApp fails, payment webhook
             * should still be called.
             */

            this.callPaymentSuccessWebhook();

            return;
          }

          this.whatsappSent = true;

          console.log(
            '=============================================='
          );

          console.log(
            'WHATSAPP SENT SUCCESSFULLY'
          );

          console.log(
            '=============================================='
          );

          /*
           * NEXT STEP
           */

          this.callPaymentSuccessWebhook();

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'Send WhatsApp API failed:',
            error
          );

          /*
           * WhatsApp failure must NOT stop the final
           * payment-success webhook.
           */

          this.callPaymentSuccessWebhook();

        }

      });
  }

  // =========================================================
  // STEP 7
  // PAYMENT SUCCESS WEBHOOK
  // =========================================================

  private callPaymentSuccessWebhook(): void {

    if (this.webhookCalled) {

      console.log(
        'Payment success webhook already called.'
      );

      return;
    }

    if (!this.referenceId) {

      console.error(
        'Webhook failed: Reference ID is missing.'
      );

      return;
    }

    const payload =
      this.buildWebhookPayload();

    console.log(
      '=============================================='
    );

    console.log(
      'CALLING PAYMENT SUCCESS WEBHOOK'
    );

    console.log(
      '=============================================='
    );

    console.log(
      'Webhook Payload:',
      payload
    );

    this.webhookLoading = true;
    this.webhookError = false;

    /*
     * Mark as called before HTTP call so duplicate calls
     * are prevented.
     */
    this.webhookCalled = true;

    this.paymentService
      .paymentSuccessWebhook(payload)
      .subscribe({

        next: (
          response: PaymentSuccessWebhookResponse
        ) => {

          console.log(
            'Payment Success Webhook Response:',
            response
          );

          this.webhookLoading = false;

          const success =
            response?.success === true;

          if (!success) {

            console.warn(
              'Payment Success Webhook returned unsuccessful response:',
              response
            );

            this.webhookSuccess = false;
            this.webhookError = true;

            this.loading = false;

            this.cdr.markForCheck();

            return;
          }

          this.webhookSuccess = true;

          /*
           * Update bank reference if backend returned
           * a newer/confirmed value.
           */

          const returnedBankReference =
            (response as any)?.bankReferenceNumber ||
            (response as any)?.bankRefNum ||
            (response as any)?.bank_ref_num ||
            '';

          if (returnedBankReference) {

            this.bankRefNum =
              String(
                returnedBankReference
              ).trim();

            localStorage.setItem(
              'bankReferenceNumber',
              this.bankRefNum
            );

            sessionStorage.setItem(
              'bankReferenceNumber',
              this.bankRefNum
            );

          }

          /*
           * Update reference if backend returned it.
           */

          const returnedReference =
            (response as any)?.referenceId ||
            (response as any)?.bookingRefId ||
            (response as any)?.refNo ||
            '';

          if (returnedReference) {

            this.referenceId =
              String(
                returnedReference
              ).trim();

            localStorage.setItem(
              'bookingReferenceId',
              this.referenceId
            );

            sessionStorage.setItem(
              'bookingReferenceId',
              this.referenceId
            );

          }

          console.log(
            '=============================================='
          );

          console.log(
            'PAYMENT SUCCESS FLOW COMPLETED'
          );

          console.log(
            'Reference:',
            this.referenceId
          );

          console.log(
            'Bank Reference:',
            this.bankRefNum
          );

          console.log(
            '=============================================='
          );

          this.loading = false;

          this.generateBarcode();

          this.cdr.markForCheck();
        },

        error: error => {

          console.error(
            'Payment Success Webhook failed:',
            error
          );

          this.webhookLoading = false;
          this.webhookError = true;
          this.loading = false;

          /*
           * Allow retry if user implements a retry button.
           */
          this.webhookCalled = false;

          this.cdr.markForCheck();
        }

      });
  }

  // =========================================================
  // BUILD WEBHOOK PAYLOAD
  // =========================================================

  private buildWebhookPayload():
  PaymentSuccessWebhookRequest {

  const userId =
    this.getStorageString('bookingUserId') ||
    this.getStorageString('userId');

  const sessionId =
    this.getStorageString(
      'tci_active_booking_session'
    );

  // =======================================================
  // PICKUP ADDRESS
  // =======================================================

  const pickupKeys: string[] = [];

  if (userId && sessionId) {

    pickupKeys.push(
      `tci_booking_pickup_address_${userId}_${sessionId}`
    );

  }

  pickupKeys.push(
    'tci_booking_pickup_address',
    'pickupAddress',
    'tci_booking_address'
  );

  const pickupAddress =
    this.getStoredJson(pickupKeys) || {};

  // =======================================================
  // DELIVERY ADDRESS
  // =======================================================

  const deliveryKeys: string[] = [];

  if (userId && sessionId) {

    deliveryKeys.push(
      `tci_booking_delivery_address_${userId}_${sessionId}`
    );

  }

  deliveryKeys.push(
    'tci_booking_delivery_address',
    'deliveryAddress'
  );

  const deliveryAddress =
    this.getStoredJson(deliveryKeys) || {};

  // =======================================================
  // SHIPMENT
  // =======================================================

  const shipmentKeys: string[] = [];

  if (userId && sessionId) {

    shipmentKeys.push(
      `tci_booking_shipment_data_${userId}_${sessionId}`
    );

  }

  shipmentKeys.push(
    'tci_booking_shipment_data',
    'shipmentData'
  );

  const shipmentData =
    this.getStoredJson(shipmentKeys) || {};

  // =======================================================
  // USER
  // =======================================================

  const userData =
    this.getStoredJson([
      'bookingUser',
      'userData',
      'loggedInUser',
      'customerData',
      'user'
    ]) || {};

  // =======================================================
  // CUSTOMER NAME
  // =======================================================

  const customerName =
    this.customerName ||
    userData['customerName'] ||
    userData['customer_name'] ||
    userData['fullName'] ||
    userData['full_name'] ||
    userData['name'] ||
    userData['contactPerson'] ||
    userData['contactPersonName'] ||
    userData['contactName'] ||
    userData['firstName'] ||
    pickupAddress['customerName'] ||
    pickupAddress['customer_name'] ||
    pickupAddress['fullName'] ||
    pickupAddress['full_name'] ||
    pickupAddress['name'] ||
    pickupAddress['contactPerson'] ||
    pickupAddress['contactPersonName'] ||
    pickupAddress['contactName'] ||
    pickupAddress['consignorName'] ||
    pickupAddress['consignor_name'] ||
    shipmentData['customerName'] ||
    shipmentData['customer_name'] ||
    shipmentData['consignorName'] ||
    shipmentData['consignor_name'] ||
    '';

  // =======================================================
  // MOBILE
  // =======================================================

  const mobileNumber =
    this.getLoggedInMobile() ||
    this.mobileNumber ||
    pickupAddress['mobileNo'] ||
    pickupAddress['mobile'] ||
    pickupAddress['phone'] ||
    '';

  // =======================================================
  // BANK REFERENCE
  // =======================================================

  const bankReferenceNumber =
    this.bankRefNum ||
    this.getStorageString(
      'bankReferenceNumber'
    ) ||
    this.getStorageString(
      'bankRefNum'
    ) ||
    '';

  // =======================================================
  // SERVICE TYPE
  // =======================================================

  const serviceType =
    this.serviceType ||
    shipmentData['serviceType'] ||
    shipmentData['shipmentType'] ||
    '';

  // =======================================================
  // PICKUP DATE
  // =======================================================

  const pickupDate =
    this.pickupDate ||
    shipmentData['pickupDate'] ||
    '';

  // =======================================================
  // ORIGIN
  // =======================================================

  const origin =
    this.pickupCity ||
    pickupAddress['city'] ||
    pickupAddress['pickupCity'] ||
    pickupAddress['location'] ||
    '';

  // =======================================================
  // DESTINATION
  // =======================================================

  const destination =
    this.deliveryCity ||
    deliveryAddress['city'] ||
    deliveryAddress['deliveryCity'] ||
    deliveryAddress['location'] ||
    '';

  // =======================================================
  // FINAL PAYLOAD
  // =======================================================

  const payload: PaymentSuccessWebhookRequest = {

    pickupReferenceNumber:
      String(this.referenceId || '').trim(),

    bankReferenceNumber:
      String(bankReferenceNumber || '').trim(),

    serviceType:
      String(serviceType || '').trim(),

    pickupDate:
      String(pickupDate || '').trim(),

    origin:
      String(origin || '').trim(),

    destination:
      String(destination || '').trim(),

    customerName:
      String(customerName || '').trim(),

    mobileNumber:
      String(mobileNumber || '').trim()

  };

  console.log(
    '=============================================='
  );

  console.log(
    'FINAL WEBHOOK PAYLOAD'
  );

  console.log(
    '=============================================='
  );

  console.log(
    JSON.stringify(
      payload,
      null,
      2
    )
  );

  console.log(
    'Bank Reference Source:',
    {
      componentValue: this.bankRefNum,
      localStorage:
        this.getStorageString(
          'bankReferenceNumber'
        ),
      sessionStorage:
        sessionStorage.getItem(
          'bankReferenceNumber'
        )
    }
  );

  console.log(
    'Customer Name Source:',
    {
      componentValue: this.customerName,
      userData,
      pickupAddress,
      shipmentData
    }
  );

  return payload;
}

  // =========================================================
  // GET LOGGED-IN MOBILE
  // =========================================================

  private getLoggedInMobile(): string {

    /*
     * IMPORTANT FIX:
     *
     * Earlier code was checking only mobileNo.
     *
     * Your application stores mobile in:
     *
     * mobileNo
     * bookingMobile
     *
     * So check both.
     */

    const mobile =
      this.getStorageString('mobileNo') ||
      this.getStorageString('bookingMobile') ||
      this.mobileNumber ||
      '';

    const cleanedMobile =
      String(mobile)
        .trim()
        .replace(/\s+/g, '');

    if (
      !/^[6-9][0-9]{9}$/.test(
        cleanedMobile
      )
    ) {

      console.error(
        'Invalid or missing logged-in mobile number:',
        cleanedMobile
      );

      return '';
    }

    return cleanedMobile;
  }

  // =========================================================
  // BARCODE
  // =========================================================

  private generateBarcode(): void {

    if (!this.referenceId) {
      return;
    }

    /*
     * Wait until DOM has rendered.
     */

    setTimeout(() => {

      const barcodeElement =
        document.getElementById(
          'bookingBarcode'
        ) as HTMLImageElement | null;

      if (!barcodeElement) {

        console.warn(
          'Barcode element not found.'
        );

        return;
      }

      try {

        JsBarcode(
          barcodeElement,
          this.referenceId,
          {
            format: 'CODE128',
            displayValue: true,
            fontSize: 16,
            height: 70,
            margin: 10
          }
        );

        console.log(
          'Barcode generated:',
          this.referenceId
        );

      } catch (error) {

        console.error(
          'Barcode generation failed:',
          error
        );

      }

    }, 100);

  }

  // =========================================================
  // GO TO NEW BOOKING
  // =========================================================

  goToBooking(): void {

    console.log(
      'Starting new booking...'
    );

    const loggedInUserId =
      this.getStorageString('bookingUserId') ||
      this.getStorageString('userId');

    const loggedInMobile =
      this.getLoggedInMobile();

    this.clearCompletedBookingData();

    /*
     * Preserve logged-in user.
     */

    if (loggedInUserId) {

      localStorage.setItem(
        'bookingUserId',
        loggedInUserId
      );

      sessionStorage.setItem(
        'bookingUserId',
        loggedInUserId
      );

    }

    if (loggedInMobile) {

      localStorage.setItem(
        'bookingMobile',
        loggedInMobile
      );

      sessionStorage.setItem(
        'bookingMobile',
        loggedInMobile
      );

    }

    /*
     * Start a new booking session.
     */

    const newSessionId =
      `${Date.now()}`;

    localStorage.setItem(
      'tci_active_booking_session',
      newSessionId
    );

    sessionStorage.setItem(
      'tci_active_booking_session',
      newSessionId
    );

    if (loggedInUserId) {

      localStorage.setItem(
        'tci_active_booking_session_user',
        loggedInUserId
      );

      sessionStorage.setItem(
        'tci_active_booking_session_user',
        loggedInUserId
      );

    }

    localStorage.setItem(
      'bookingSessionActive',
      'true'
    );

    sessionStorage.setItem(
      'bookingSessionActive',
      'true'
    );

    this.router.navigate(
      ['/address']
    );
  }

  // =========================================================
  // GO TO HOME
  // =========================================================

  goToHome(): void {

    console.log(
      'Going to service check page...'
    );

    this.clearCompletedBookingData();

    this.router.navigate(
      ['/service-check']
    );
  }

  // =========================================================
  // CLEAR COMPLETED BOOKING DATA
  // =========================================================

  private clearCompletedBookingData(): void {

    const keysToRemove = [

      // Payment
      'paymentTxnId',
      'txnId',
      'paymentAmount',
      'amount',
      'mihpayId',
      'paymentMode',

      // Booking
      'bookingOrderId',
      'orderId',
      'bookingReferenceId',
      'referenceId',

      // CMF
      'custcode',
      'groupCustCode',

      // Payment refs
      'bankReferenceNumber',
      'bankRefNum',

      // Current booking session
      'tci_active_booking_session',
      'tci_active_booking_session_user',
      'bookingSessionActive',

      // Old generic keys
      'tci_booking_address',
      'tci_booking_shipment_data',
      'shipmentData',
      'pickupAddress',
      'deliveryAddress'

    ];

    keysToRemove.forEach(key => {

      localStorage.removeItem(key);
      sessionStorage.removeItem(key);

    });

    /*
     * Remove user/session-specific booking data.
     *
     * Saved addresses are intentionally NOT removed.
     */

    const userId =
      this.getStorageString('bookingUserId') ||
      this.getStorageString('userId');

    const sessionId =
      this.getStorageString(
        'tci_active_booking_session'
      );

    if (userId && sessionId) {

      const sessionKeys = [

        `tci_booking_pickup_address_${userId}_${sessionId}`,

        `tci_booking_delivery_address_${userId}_${sessionId}`,

        `tci_booking_shipment_data_${userId}_${sessionId}`

      ];

      sessionKeys.forEach(key => {

        localStorage.removeItem(key);
        sessionStorage.removeItem(key);

      });

    }

  }

  // =========================================================
  // STORAGE HELPERS
  // =========================================================

  private getStorage(
    key: string
  ): string {

    const localValue =
      localStorage.getItem(key);

    if (
      localValue !== null &&
      localValue !== undefined
    ) {

      return localValue;
    }

    const sessionValue =
      sessionStorage.getItem(key);

    if (
      sessionValue !== null &&
      sessionValue !== undefined
    ) {

      return sessionValue;
    }

    return '';
  }

  // =========================================================
  // GET STRING FROM STORAGE
  // =========================================================

  private getStorageString(
    key: string
  ): string {

    const value =
      this.getStorage(key);

    return value
      ? String(value).trim()
      : '';
  }

  // =========================================================
  // GET JSON OBJECT
  // =========================================================

  private getStorageObject(
    key: string
  ): any | null {

    const value =
      this.getStorage(key);

    if (!value) {
      return null;
    }

    try {

      return JSON.parse(value);

    } catch (error) {

      console.warn(
        `Unable to parse storage key "${key}"`,
        error
      );

      return null;
    }
  }

  // =========================================================
  // GET JSON FROM MULTIPLE POSSIBLE KEYS
  // =========================================================

  private getStoredJson(
    keys: string[]
  ): any | null {

    for (const key of keys) {

      const value =
        this.getStorageObject(key);

      if (value) {

        return value;
      }

    }

    return null;
  }

  // =========================================================
  // VALIDATE POSITIVE NUMBER
  // =========================================================

  private isValidPositiveNumber(
    value: number
  ): boolean {

    return (
      Number.isFinite(value) &&
      value > 0
    );
  }

}
