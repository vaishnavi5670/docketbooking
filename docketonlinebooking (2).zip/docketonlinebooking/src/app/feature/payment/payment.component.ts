import { Component } from '@angular/core';
import {RouterLink} from '@angular/router'
import {BookingShellComponent} from '../../shared/components/booking-shell/booking-shell.component';
@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [RouterLink, BookingShellComponent],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {

}
