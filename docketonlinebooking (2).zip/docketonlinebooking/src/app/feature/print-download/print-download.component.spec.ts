import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintDownloadComponent } from './print-download.component';

describe('PrintDownloadComponent', () => {
  let component: PrintDownloadComponent;
  let fixture: ComponentFixture<PrintDownloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrintDownloadComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PrintDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
