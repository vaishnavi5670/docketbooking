import { Component } from '@angular/core';

@Component({
  selector: 'app-print-download',
  standalone: true,
  imports: [],
  templateUrl: './print-download.component.html',
  styleUrl: './print-download.component.css'
})
export class PrintDownloadComponent {

}
