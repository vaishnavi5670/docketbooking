
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import {RegisterModel} from '../models/onlinebooking.model';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  isRegistering = false;
  errorMessage = '';

  register: RegisterModel = {
    firstName: '',
    lastName: '',
    mobile: '',
    email: '',
    companyName: '',
    password: '',
    confirmPassword: '',
    consent: false
  };

  constructor(private authService: AuthService,private router: Router) {}

  registerUser(): void {
    this.errorMessage = ''; if (!this.register.firstName.trim()) {this.errorMessage = 'Please enter first name.';return;}
    if (!this.register.lastName.trim()) {this.errorMessage = 'Please enter last name.';return;}
    if (!this.register.mobile.trim()) {this.errorMessage = 'Please enter mobile number.';return;}
    if (!/^[0-9]{10}$/.test(this.register.mobile)) {this.errorMessage = 'Please enter a valid 10-digit mobile number.';return;}
    if (!this.register.password) {this.errorMessage = 'Please enter password.';return;}
    if (this.register.password !== this.register.confirmPassword) { this.errorMessage = 'Password and confirm password do not match.'; return;}
    if (!this.register.consent) { this.errorMessage =   'Please agree to the Terms & Conditions and Privacy Policy.'; return;}
    this.isRegistering = true;

    const payload = { firstName: this.register.firstName.trim(),
    lastName: this.register.lastName.trim(),
    mobileNo: this.register.mobile.trim(),
    email: this.register.email?.trim() || '',
    password: this.register.password,
    confirmPassword: this.register.confirmPassword,
    acceptTerms: this.register.consent };

    this.authService.register(payload).subscribe({ next: (response: any) => {
    this.isRegistering = false; if (response?.success) { alert( response?.message || 'Account created successfully.' );
    this.router.navigate(['/login']); } else { this.errorMessage = response?.message || 'Unable to create account.'; } }, error: (error: any) => {
    this.isRegistering = false; this.errorMessage = error?.error?.message || 'Registration failed. Please try again.'; console.error( 'Registration error:', error ); } });
  }
}

