
import { ChangeDetectionStrategy, ChangeDetectorRef, Component} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { BookingShellComponent } from '../../shared/components/booking-shell/booking-shell.component';
import { AuthService} from '../../services/auth.service';
import { PinCodeLocation } from '../models/onlinebooking.model';
import { PinCodeCheckRequest } from '../models/onlinebooking.model';
import { PinCodeCheckResponse } from '../models/onlinebooking.model';

@Component({
  selector: 'app-service-check',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterLink,BookingShellComponent],
  templateUrl: './service-check.component.html',
  styleUrl: './service-check.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiceCheckComponent {
  pickupPincode = '';
  deliveryPincode = '';
  serviceChecked = false;
  serviceAvailable = false;
  loading = false;
  errorMessage = '';
  successMessage = '';
  pickupDetails: PinCodeLocation | null = null;
  deliveryDetails: PinCodeLocation | null = null;

  constructor(private readonly authService: AuthService,private readonly cdr: ChangeDetectorRef) {
    this.loadSavedPincodes();
  }

private loadSavedPincodes(): void {

  const sessionId =
    localStorage.getItem(
      'tci_active_booking_session'
    )?.trim();

  const sessionUserId =
    localStorage.getItem(
      'tci_active_booking_session_user'
    )?.trim();

  const currentUserId =
    localStorage.getItem(
      'bookingUserId'
    )?.trim();

  const validSession =
    !!sessionId &&
    !!sessionUserId &&
    !!currentUserId &&
    sessionUserId === currentUserId;

  if (!validSession) {

    this.pickupPincode = '';
    this.deliveryPincode = '';

    return;
  }

  this.pickupPincode =
    localStorage.getItem(
      'serviceCheckPickupPincode'
    ) ||
    localStorage.getItem(
      'pickupPincode'
    ) ||
    '';

  this.deliveryPincode =
    localStorage.getItem(
      'serviceCheckDeliveryPincode'
    ) ||
    localStorage.getItem(
      'deliveryPincode'
    ) ||
    '';
}

  checkServiceAvailability(): void {
    if (this.loading) {
      return;
    }
    this.resetResult();
    this.pickupPincode =this.pickupPincode.trim();
    this.deliveryPincode = this.deliveryPincode.trim();
    if (!this.isValidPincode(this.pickupPincode)) {
      this.errorMessage = 'Please enter a valid 6-digit Pickup PIN Code.';
      this.serviceChecked = true;
      this.cdr.markForCheck();
      return;
    }
    if (!this.isValidPincode(this.deliveryPincode)) {
      this.errorMessage ='Please enter a valid 6-digit Delivery PIN Code.';
      this.serviceChecked = true;
      this.cdr.markForCheck();
      return;
    }
    this.savePincodes();
    const request: PinCodeCheckRequest = {
      pickupPincode: this.pickupPincode,
      deliveryPincode: this.deliveryPincode
    };
    this.loading = true;
    this.cdr.markForCheck();
    this.authService.checkPincode(request).subscribe({
      next: (response: PinCodeCheckResponse) => {

        this.loading = false;
        this.serviceChecked = true;
        this.pickupDetails =response.pickup ?? null;
        this.deliveryDetails = response.delivery ?? null;
        if (
          response.success === true &&
          response.serviceAvailable === true
        ) {
          this.handleServiceAvailable(response);
        }
        else {
          this.handleServiceUnavailable(response);
        }
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error(
          'Pincode Service Check API Error:',
          error
        );
        this.loading = false;
        this.serviceChecked = true;
        this.serviceAvailable = false;
        this.pickupDetails = null;
        this.deliveryDetails = null;
        this.errorMessage =
          'Unable to check service availability. Please try again.';
        this.cdr.markForCheck();
      }
    });

  }

  private handleServiceAvailable(
    response: PinCodeCheckResponse): void {
    this.serviceAvailable = true;
    this.successMessage = response.message ||
      `Service is available from ` +
      `${response.pickup.city} to ` +
      `${response.delivery.city}.`;
    this.saveLocationDetails(response);
  }

  private handleServiceUnavailable( response: PinCodeCheckResponse): void {
    this.serviceAvailable = false;
    const pickupServiceable = response.pickup?.location === 'S';
    const deliveryServiceable =response.delivery?.location === 'S';
    if (
      !pickupServiceable &&
      deliveryServiceable
    ) {
      this.errorMessage =
        `Pickup PIN Code ${response.pickup.pincode} ` +
        `(${response.pickup.city}) is not serviceable.`;
      return;
    }
    if (
      pickupServiceable &&
      !deliveryServiceable
    ) {
      this.errorMessage =
        `Delivery PIN Code ${response.delivery.pincode} ` +
        `(${response.delivery.city}) is not serviceable.`;
      return;
    }

    if (
      !pickupServiceable &&
      !deliveryServiceable
    ) {

      this.errorMessage =
        `Pickup PIN Code ${response.pickup.pincode} ` +
        `(${response.pickup.city}) and ` +
        `Delivery PIN Code ${response.delivery.pincode} ` +
        `(${response.delivery.city}) are not serviceable.`;

      return;
    }

    this.errorMessage =
      response.message ||
      `Service is not available from ` +
      `Pickup PIN Code ${response.pickup.pincode} ` +
      `(${response.pickup.city}) to ` +
      `Delivery PIN Code ${response.delivery.pincode} ` +
      `(${response.delivery.city}).`;

  }


private saveLocationDetails(
  response: PinCodeCheckResponse
): void {

  const pickupPincode =
    response.pickup?.pincode ||
    this.pickupPincode ||
    '';

  const pickupCity =
    response.pickup?.city || '';

  const pickupState =
    response.pickup?.state || '';

  const pickupLocation =
    response.pickup?.location || '';

  const pickupBranchCode =
    response.pickup?.branchCode || '';

  const deliveryPincode =
    response.delivery?.pincode ||
    this.deliveryPincode ||
    '';

  const deliveryCity =
    response.delivery?.city || '';

  const deliveryState =
    response.delivery?.state || '';

  const deliveryLocation =
    response.delivery?.location || '';

  const deliveryBranchCode =
    response.delivery?.branchCode || '';

  // ============================
  // PICKUP
  // ============================

  localStorage.setItem(
    'serviceCheckPickupPincode',
    pickupPincode
  );

  localStorage.setItem(
    'serviceCheckPickupCity',
    pickupCity
  );

  localStorage.setItem(
    'serviceCheckPickupState',
    pickupState
  );

  localStorage.setItem(
    'serviceCheckPickupLocation',
    pickupLocation
  );

  localStorage.setItem(
    'serviceCheckPickupBranchCode',
    pickupBranchCode
  );

  // ============================
  // DELIVERY
  // ============================

  localStorage.setItem(
    'serviceCheckDeliveryPincode',
    deliveryPincode
  );

  localStorage.setItem(
    'serviceCheckDeliveryCity',
    deliveryCity
  );

  localStorage.setItem(
    'serviceCheckDeliveryState',
    deliveryState
  );

  localStorage.setItem(
    'serviceCheckDeliveryLocation',
    deliveryLocation
  );

  localStorage.setItem(
    'serviceCheckDeliveryBranchCode',
    deliveryBranchCode
  );

  // Legacy keys
  localStorage.setItem(
    'pickupPincode',
    pickupPincode
  );

  localStorage.setItem(
    'pickupCity',
    pickupCity
  );

  localStorage.setItem(
    'pickupState',
    pickupState
  );

  localStorage.setItem(
    'pickupLocation',
    pickupLocation
  );

  localStorage.setItem(
    'pickupBranchCode',
    pickupBranchCode
  );

  localStorage.setItem(
    'deliveryPincode',
    deliveryPincode
  );

  localStorage.setItem(
    'deliveryCity',
    deliveryCity
  );

  localStorage.setItem(
    'deliveryState',
    deliveryState
  );

  localStorage.setItem(
    'deliveryLocation',
    deliveryLocation
  );

  localStorage.setItem(
    'deliveryBranchCode',
    deliveryBranchCode
  );
}
private savePincodes(): void {
  localStorage.setItem('serviceCheckPickupPincode', this.pickupPincode);
  localStorage.setItem('serviceCheckDeliveryPincode',this.deliveryPincode);
  localStorage.setItem( 'pickupPincode', this.pickupPincode);
  localStorage.setItem('deliveryPincode',this.deliveryPincode
  );
}

private isValidPincode(pincode: string): boolean {
    return /^[0-9]{6}$/.test(pincode);}


onPincodeInput(type: 'pickup' | 'delivery', event: Event): void {
  const input = event.target as HTMLInputElement;
  const value = input.value .replace(/\D/g, '') .slice(0, 6);
  input.value = value;
  if (type === 'pickup') {this.pickupPincode = value;
  } else {this.deliveryPincode = value;
  }
  this.resetResult();
  this.cdr.markForCheck();
}

  private resetResult(): void {
    this.serviceChecked = false;
    this.serviceAvailable = false;
    this.errorMessage = '';
    this.successMessage = '';
    this.pickupDetails = null;
    this.deliveryDetails = null;

  }
  swapPincodes(): void {
    [this.pickupPincode,this.deliveryPincode] = [ this.deliveryPincode, this.pickupPincode];
    this.savePincodes();
    this.resetResult();
    this.cdr.markForCheck();

  }
}
