import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';


export interface DeliveryAddress {
  id: number;
  userId: number;
  orderId: string;
  contactName: string;
  mobileNumber: string;
  email: string;
  companyName: string;
  address: string;
  landmark: string;
  pincode: string;
  city: string;
  state: string;
  deliveryDate: string;
  deliveryTime: string;
  createdDate: string;
}

export interface DeliveryAddressResponse {
  success: boolean;
  message: string;
  userId: number;
  count: number;
  data: DeliveryAddress[];
}

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  private readonly apiUrl =
    `${environment.apiUrl}/Address`;

  constructor(
    private readonly http: HttpClient
  ) {}

  // SAVE ADDRESS
  saveAddress(payload: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}/save`,
      payload
    );
  }

  // GET PREVIOUSLY USED DELIVERY ADDRESSES
  getDeliveryAddresses(
    userId: number
  ): Observable<DeliveryAddressResponse> {

    return this.http.get<DeliveryAddressResponse>(
      `${this.apiUrl}/delivery-addresses/${userId}`
    );
  }
}
