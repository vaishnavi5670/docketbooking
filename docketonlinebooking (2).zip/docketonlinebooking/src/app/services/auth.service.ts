import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';
import { PinCodeCheckResponse, PinCodeCheckRequest} from '../feature/models/onlinebooking.model';
import { RegisterRequest } from '../feature/models/onlinebooking.model';
import { RegisterResponse } from '../feature/models/onlinebooking.model';

export interface LoginResponse {
  success: boolean;
  message: string;
  otpRequired: boolean;
  mobileNo: string;
  userId: number;
}

export interface VerifyOtpResponse {
  success: boolean;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  checkPincode( request: PinCodeCheckRequest): Observable<PinCodeCheckResponse> {
    return this.http.post<PinCodeCheckResponse>(
      `${this.apiUrl}/Auth/pincodecheck`,
      request
    );
  }


  login(mobile: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(
      `${this.apiUrl}/Auth/login`,
      {
        mobileNO: mobile
      }
    );
  }


  verifyOtp( mobile: string, otp: string): Observable<VerifyOtpResponse> {
    return this.http.post<VerifyOtpResponse>(
      `${this.apiUrl}/Auth/verify-otp`,
      {
        mobileNO: mobile,
        otp: otp
      }
    );
  }



  register( request: RegisterRequest ): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>( `${this.apiUrl}/Auth/register`, request ); }
}
