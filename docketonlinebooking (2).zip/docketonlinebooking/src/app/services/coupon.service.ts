import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';

export interface Coupon {
  promoCode: string;
  validUpto: string;
  validFor: string;
  amount: number;
  createDate: string;
}

export interface CouponResponse {
  status: boolean;
  userId: number;
  panNo: string;
  data: Coupon[];
}

@Injectable({
  providedIn: 'root'
})
export class CouponService {

private readonly apiUrl = environment.apiUrl;
  constructor(private readonly http: HttpClient) {}

  getCoupons(userId: number,mobileNo?: string): Observable<CouponResponse> {
  const body: {
    userId: number;
    mobileNo?: string;
  } = { userId };
  if (mobileNo?.trim()) {
    body.mobileNo = mobileNo.trim();
  }
  return this.http.post<CouponResponse>(
    `${this.apiUrl}/Coupon/GetCoupons`,
    body
  );
}
}
