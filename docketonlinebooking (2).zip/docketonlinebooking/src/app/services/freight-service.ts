import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class FreightCalculatorService {

 private readonly freightApiUrl ='https://customerportal.tciexpress.in/api/v1/Home/Freightcalculator';

  constructor(private http: HttpClient) {}

  calculateFreight(payload: any): Observable<any> {return this.http.post<any>(
      this.freightApiUrl,
      payload
    );
  }

}
