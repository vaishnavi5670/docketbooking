import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';
import {VerificationResponse} from '../feature/models/onlinebooking.model'
import {SavePanGstRequest} from '../feature/models/onlinebooking.model'
import {SavePanGstResponse} from '../feature/models/onlinebooking.model'

@Injectable({
  providedIn: 'root'
})
export class PanGstService {

  private readonly baseUrl = `${environment.apiUrl}/Verification`;

  constructor(private http: HttpClient) {}

  verifyPan(panNumber: string): Observable<VerificationResponse> {
    return this.http.post<VerificationResponse>(
      `${this.baseUrl}/pan`,
      {
        panNumber: panNumber
      }
    );
  }

  verifyGst(gstNumber: string): Observable<VerificationResponse> {
    return this.http.post<VerificationResponse>(
      `${this.baseUrl}/gst`,
      {
        gstNumber: gstNumber
      }
    );
  }

  savePanGst(payload: SavePanGstRequest): Observable<SavePanGstResponse> {
    return this.http.post<SavePanGstResponse>( `${this.baseUrl}/save-pan-gst`,payload);
  }
}
