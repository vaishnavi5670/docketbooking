
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';
import { PayURequest } from '../feature/models/onlinebooking.model';
import { PayUResponse } from '../feature/models/onlinebooking.model';
import {PayUData} from '../feature/models/onlinebooking.model';
import { PaymentSuccessWebhookRequest } from '../feature/models/onlinebooking.model';
import { PaymentSuccessWebhookResponse } from '../feature/models/onlinebooking.model';

export interface WhatsAppRequest { refNo: string; phone: string; }
export interface WhatsAppResponse { success: boolean; message?: string; referenceNo?: string; phone?: string; }


@Injectable({
  providedIn: 'root'
})


export class PaymentService {

  private readonly apiUrl =environment.apiUrl;

  constructor(private readonly http: HttpClient) {}


  initiatePayment(request: PayURequest): Observable<PayUResponse> {
    return this.http.post<PayUResponse>(
      `${this.apiUrl}/Payment/pay`,
      request
    );

  }

  submitToPayU( paymentUrl: string,data: PayUData): void {
    if (!paymentUrl) { throw new Error( 'PayU payment URL is missing.');}
    if (!data) {throw new Error(  'PayU payment data is missing.');}
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = paymentUrl;
    form.style.display = 'none';
    const fields: Record<string, string> = {
    key: data.key || '',
    txnid:data.txnid || '',
    amount: data.amount || '',
    productinfo:data.productinfo || '',
    firstname:data.firstname || '',
    email:data.email || '',
    phone:data.phone || '',
    surl:data.surl || '',
    furl:data.furl || '',
    hash:data.hash || '',
    udf1:data.udf1 || '',
    udf2:data.udf2 || '',
    udf3: data.udf3 || '',
    udf4:data.udf4 || '',
    udf5:data.udf5 || '',
    service_provider:data.service_provider || 'payu'};
    Object.entries(fields).forEach(([name, value]) => {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = name;
    input.value = value;
    form.appendChild(input); });
    document.body.appendChild(form);
    form.submit();

}

sendBookingWhatsApp( refNo: string, phone: string ): Observable<WhatsAppResponse> {
   const request: WhatsAppRequest = { refNo: refNo, phone: phone };
   return this.http.post<WhatsAppResponse>( `${this.apiUrl}/Payment/send-whatsapp`, request );
  }

savePaymentSuccess(payload: {userId: number;orderId: string;bookingRefId: string;transactionId: string;amountPaid: number;paymentId: string;paymentMode: string;  bankRefNum: string;
}) { return this.http.post<any>(`${this.apiUrl}/Payment/save-payment-success`,payload
  );
}

generateReference(orderId: string) {
  return this.http.post<{success: boolean; message: string; orderId: string; referenceId: string;
  }>(`${this.apiUrl}/Payment/generate-reference`,{orderId}
  );
}

saveCmfPickup(orderId: string, custcode: string) {
  return this.http.post<any>(`${this.apiUrl}/CMFPICKUP/pickuprqst_save`,
    { orderId: orderId, custcode: custcode}
  );
}

createCustCode(orderId: string) {
  return this.http.post<any>( `${this.apiUrl}/CMFPICKUP/CustCode`,
    { orderId, multiple: false}
  );
}

saveCustomerInformation(orderId: string,groupCustCode: number,custCode: number) {
  return this.http.post<any>(`${this.apiUrl}/CMFPICKUP/CustomerInformation`,
    { orderId,groupCustCode,custCode,audUser: orderId
    }
  );
}

paymentSuccessWebhook( payload: PaymentSuccessWebhookRequest ): Observable<PaymentSuccessWebhookResponse> {
  return this.http.post<PaymentSuccessWebhookResponse>( `${this.apiUrl}/payu/webhook/payment-success`, payload ); }
}



