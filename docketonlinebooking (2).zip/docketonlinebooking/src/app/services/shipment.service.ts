import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShipmentGetResponse } from '../feature/models/onlinebooking.model';
import { environment } from '../environment/environment';
import {SaveShipmentRequest} from '../feature/models/onlinebooking.model'
import {CheckBookingDateRequest} from '../feature/models/onlinebooking.model'
import {CheckBookingDateResponse} from '../feature/models/onlinebooking.model'

@Injectable({
  providedIn: 'root'
})
export class ShipmentService {

  private readonly apiUrl =`${environment.apiUrl}`;
  constructor(private http: HttpClient) {}

saveShipment(payload: SaveShipmentRequest): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/Shipment/save`,payload);
}

getShipment(id: number): Observable<ShipmentGetResponse> {
    return this.http.get<ShipmentGetResponse>( `${this.apiUrl}/Shipment/get/${id}` );
}

getShipmentPackageDetails(orderId: string): Observable<any> {
  return this.http.get<any>(
    `${this.apiUrl}/Shipment/get/${orderId}`
  );
 }

checkBookingDate(request: CheckBookingDateRequest): Observable<CheckBookingDateResponse> {
    return this.http.post<CheckBookingDateResponse>(`${this.apiUrl}/Auth/CheckBookingDate`,
      request
    );
  }
}
