import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ Router } from '@angular/router';

@Component({
  selector: 'app-booking-shell',
  standalone: true,
  imports: [ CommonModule],
  templateUrl: './booking-shell.component.html',
  styleUrl: './booking-shell.component.css'
})
export class BookingShellComponent {

  constructor(private router: Router) {}

  @Input() activeStep: number = 1;
  @Input() pageTitle: string = '';
  @Input() pageSubtitle: string = '';

userName =''
userMobile = '';
totalOrders = 0;
completedOrders = 0;
pendingOrders = 0;

showUserMenu = false;

  logout(): void {

  localStorage.removeItem('bookingUserId');
  localStorage.removeItem('bookingMobile');
  localStorage.removeItem('userId');
  localStorage.removeItem('mobileNo');
  localStorage.removeItem('bookingUserName');
  localStorage.removeItem('tci_active_booking_session');
  localStorage.removeItem('tci_active_booking_session_user');
  this.router.navigate(['/login']);
}

loadOrderDetails(): void {
  this.totalOrders = 12;
  this.completedOrders = 9;
  this.pendingOrders = 3;
}
toggleUserMenu(): void {
  this.showUserMenu = !this.showUserMenu;
}
viewOrders(): void {
  this.showUserMenu = false;

  this.router.navigate(['/orders']);
}
}
