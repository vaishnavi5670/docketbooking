import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

     @Input() activeStep = 0;
     @Input() pageTitle = 'ONLINE BOOKING';
     @Input() pageSubtitle =
    'Provide accurate shipment and package information';
}
