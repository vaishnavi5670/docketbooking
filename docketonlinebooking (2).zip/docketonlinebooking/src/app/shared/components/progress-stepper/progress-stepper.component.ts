import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-progress-stepper',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './progress-stepper.component.html',
  styleUrls: ['./progress-stepper.component.css']
})
export class ProgressStepperComponent {

  @Input() activeStep: number = 1;

  steps = [
    {
      number: 1,
      title: 'Pickup & Delivery Address',
      icon: 'location'
    },
    {
      number: 2,
      title: 'Shipment & Package Details',
      icon: 'number'
    },
    {
      number: 3,
      title: 'Payment & Confirmation',
      icon: 'number'
    }
  ];

  isCompleted(stepNumber: number): boolean {
    return stepNumber < this.activeStep;
  }

  isActive(stepNumber: number): boolean {
    return stepNumber === this.activeStep;
  }

  isUpcoming(stepNumber: number): boolean {
    return stepNumber > this.activeStep;
  }
}
